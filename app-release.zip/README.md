# SynthOS — local AI jobs + Android app workspace

This archive contains the current Android source under `source/`. It preserves the installed-app browser and SynthOS Live control panel, and adds the missing local-AI job pipeline: LiteRT-LM model import/inference, skill selection, evidence-bounded context assembly, persisted jobs and conversation history, strict typed-plan validation, and workflow drafts that require review before execution.

## Build the APK

This ZIP contains Android source, not a compiled APK. Build on GitHub Actions with the existing `Build SynthOS APK` workflow, or on a machine with JDK 17 and Android SDK Platform 35:

```bash
cd source
./gradlew --no-daemon clean assembleRelease
```

The output is `source/app/build/outputs/apk/release/app-release.apk`. I cannot honestly claim this source was built or device-tested in this environment; the Android SDK is unavailable here. The next verification gate is the existing CI build and a real phone run.

## First-run steps

1. Install the resulting APK and unlock SynthOS.
2. Open **Settings → Local AI**. Use **Get starter model · Qwen2 0.5B (~647 MB)** or import your own compatible `.litertlm` file. The starter button opens the official Hugging Face model file page in an external browser; SynthOS does not download model weights itself.
3. In **Apps**, choose the installed app you want to use. **Open app** launches it; **Watch + control** enables the floating SynthOS Live panel after Android permission setup.
4. Return to **Home** and chat with SynthOS. Every request becomes a durable job. SynthOS chooses relevant versioned skills and supplies the selected app's latest exposed UI labels when available.
5. Ask SynthOS to create a task, inspect an app, or draft a workflow. Workflow drafts appear in **Flows** for your review; inference never silently starts the runner.

## What the local AI can and cannot do

The model can interpret bounded context, report what an observed screen suggests, create a durable task, ask for missing input, and propose a workflow. SynthOS parses a strict JSON contract, checks allowed step types and target packages, applies `WorkflowPolicy`, and stores the result. Unsupported/malformed proposals are marked for review and do not execute. Supported outcomes include answers, evidence-bounded app inspection, durable task creation and status updates, evidence-linked capability notes, and workflow drafts. The runtime is intentionally narrow rather than granting the model unrestricted Android tools.

The app uses Google AI Edge LiteRT-LM (`litertlm-android:0.18.0`) and expects a compatible `.litertlm` model. GGUF and `.task` files cannot be loaded directly. Model weights are not bundled because even a compact model adds hundreds of megabytes. Model inference runs on-device via CPU; actual speed and memory fit depend on the phone.

The apps remain real Android apps with a floating SynthOS panel above the foreground target. This is not a video mirror or virtual Android guest. Accessibility visibility varies by app; locked-screen or fully unattended automation is not promised.


## Local AI job pipeline (0.3.0)

SynthOS uses LiteRT-LM on-device inference with an imported `.litertlm` model (weights are not bundled in this source ZIP). The user message is persisted as an encrypted job, matched to versioned skills, and assembled with bounded app metadata plus the most recent Accessibility labels. Model output is parsed as typed JSON. Supported outcomes include answers, app inspection with evidence-linked capability notes, durable task creation, task-state updates, and proposed workflows. Invalid output becomes review-required; proposed workflows pass app policy and need an explicit user-start action. Tasks and capability notes are stored in the encrypted local vault.

The package intentionally does not add an INTERNET permission; the optional starter-model page opens in the external browser. A source ZIP is not an APK. Build through the included GitHub Actions workflow on a runner with Android SDK 35. Actual compilation and on-device inference/Accessibility tests could not be run in the current container because the Android SDK and Gradle distribution are unavailable.
