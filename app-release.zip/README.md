# SynthOS App Runtime — installable build package

This archive contains the full Android source under `source/`. The current build environment has no Android SDK/Gradle installation and cannot reach the network, so it could not create a genuine APK locally. The included GitHub Actions workflow detects that no prebuilt APK is present, builds the source with JDK 17 and Android SDK 35, signs the sideload artifact with the generated debug signing key, and publishes it as `app-apk`.

## Build locally

```bash
cd source
./gradlew --no-daemon clean assembleRelease
```

Copy `source/app/build/outputs/apk/release/app-release.apk` to your Android phone and install it. See `source/README.md` and `source/ARCHITECTURE.md` for setup, privacy notes, constraints and verification steps.

## Important capability boundary

This is a visible, user-authored Android UI workflow runner. It does not claim to provide arbitrary screen-off automation, a virtual Android device or a local LLM. Workflows pause when the device is locked and do not run ad engagement, reward claims, CAPTCHA/security bypasses or payment confirmations.
