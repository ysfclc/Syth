# SynthOS App Runtime — installable build package

This archive contains the Android source under `source/`. It now includes an **Apps** workspace and the floating **SynthOS Live** control panel: browse installed launcher apps, open one normally, or watch a selected app while SynthOS displays its accessible UI labels and lets you tap exposed controls. The latest surface snapshot is shown again in SynthOS when you return to the console.

## Build an APK

This archive contains source, not a prebuilt APK. The current working environment has no Android SDK or installed Gradle and cannot fetch the required distributions, so I could not honestly produce or device-test an APK here. The repository's GitHub Actions workflow builds the source with JDK 17 and Android SDK 35, signs a sideload artifact with the generated debug signing key, verifies it, and publishes the `app-apk` artifact.

```bash
cd source
./gradlew --no-daemon clean assembleRelease
```

The APK output is `source/app/build/outputs/apk/release/app-release.apk`. See `source/README.md` and `source/ARCHITECTURE.md` for permission setup, architecture, privacy notes, supported behavior, and limitations.

## How Apps and SynthOS Live work

1. Open **Apps** and search the launchable apps installed on your phone.
2. **Open app** launches the real app. **Watch + control** asks you to enable SynthOS in Android Accessibility settings and permit **Display over other apps**.
3. The selected app stays the real foreground app. A draggable floating SynthOS Live panel shows labels and controls exposed by Android Accessibility. Tap a highlighted row to activate that control, use Back, refresh the observation, collapse the panel, or return to the SynthOS console.
4. The Apps screen shows the last accessible UI snapshot. The snapshot exists in process memory; it is not written to the workflow vault or sent to a server.

## Important capability boundary

Android does not let a normal app arbitrarily embed another installed app's Activity inside its own screen. This implementation therefore uses the real app plus a floating control surface; it is **not** a pixel-stream/video mirror, a nested Android VM, or a headless executor. Some apps expose limited Accessibility metadata (especially games, custom-drawn surfaces, and protected windows), so their labels/actions may not be available. Manual taps outside the panel still reach the underlying app. Use the Accessibility permission only if you trust SynthOS.

The app has no `INTERNET` permission and does not include a local LLM in this release. Workflows remain visible, user-authored actions; they pause when the phone is locked or the target app leaves the foreground. The release is signed with a generated debug signing key for sideload testing, not production distribution. Installing this build over a differently signed prior debug build may require uninstalling the older test build first.
