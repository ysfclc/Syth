# SynthOS — local AI jobs + Android app workspace

This archive contains the current Android source under `source/`. It preserves the installed-app browser and SynthOS Live control panel, and adds the missing local-AI job pipeline: LiteRT-LM model import/inference, skill selection, evidence-bounded context assembly, persisted jobs and conversation history, strict typed-plan validation, and workflow drafts that require review before execution.

## Build the APK

This ZIP contains Android source, not a compiled APK. Build on GitHub Actions with the existing `Build SynthOS APK` workflow, or on a machine with JDK 17 and Android SDK Platform 35:

```bash
cd source
./gradlew --no-daemon clean assembleRelease
```

The output is `source/app/build/outputs/apk/release/app-release.apk`. I cannot honestly claim this source was built or device-tested in this environment; the Android SDK is unavailable here. The Gradle distribution could not be fetched in this environment because outbound DNS/network access is unavailable. The next verification gate is the existing CI build and a real phone run.

## First-run steps

1. Install the resulting APK and unlock SynthOS.
2. Open **Settings → Local AI → One-click setup · scan for existing models**. SynthOS first checks its own private model library. Then choose the Downloads or other folder where you keep models; Android grants access to that folder, and SynthOS scans its accessible subfolders. Select a `.litertlm` file to import it, or choose **Import all compatible**. Files such as `.gguf`, `.task`, `.tflite` and `.onnx` are detected and reported, but this build cannot run them. If you prefer, use **Import model** to select one file directly. The setup flow can download two published LiteRT-LM bundles directly from the LiteRT Community Hugging Face repositories: Qwen3 0.6B and Gemma 4 E2B. Downloads show progress, can be cancelled, are stored in private app storage, and are checked against the server-reported Content-Length before installation. SynthOS records SHA-256, but does not compare it against a publisher-provided checksum. A completed download is not proof the file will run; runtime loading is tested on first use. Download requires network access and may consume hundreds of MB or several GB.
3. In **Apps**, choose the installed app you want to use. **Open app** launches it; **Watch + control** enables the floating SynthOS Live panel after Android permission setup.
4. Return to **Home** and chat with SynthOS. Every request becomes a durable job. SynthOS chooses relevant versioned skills and supplies the selected app's latest exposed UI labels when available.
5. Ask SynthOS to create a task, inspect an app, or draft a workflow. Workflow drafts appear in **Flows** for your review; inference never silently starts the runner.

## What the local AI can and cannot do

The model can interpret bounded context, report what an observed screen suggests, create a durable task, ask for missing input, and propose a workflow. SynthOS parses a strict JSON contract, checks allowed step types and target packages, applies `WorkflowPolicy`, and stores the result. Unsupported/malformed proposals are marked for review and do not execute. Supported outcomes include answers, evidence-bounded app inspection, durable task creation and status updates, evidence-linked capability notes, and workflow drafts. The runtime is intentionally narrow rather than granting the model unrestricted Android tools.

The app uses Google AI Edge LiteRT-LM (`litertlm-android:0.18.0`) and expects a compatible `.litertlm` model. Multiple imported model files can coexist, but this build loads one active model at a time. Role-specific model routing, simultaneous multi-engine loading, GGUF/llama.cpp, and vision-model execution are not implemented; GGUF and `.task` files cannot be loaded directly. Model weights are not bundled because even a compact model adds hundreds of megabytes. Model inference runs on-device via CPU; actual speed and memory fit depend on the phone.

The apps remain real Android apps with a floating SynthOS panel above the foreground target. This is not a video mirror or virtual Android guest. Accessibility visibility varies by app; locked-screen or fully unattended automation is not promised.


## Local AI job pipeline (0.3.0)

SynthOS uses LiteRT-LM on-device inference with an imported `.litertlm` model (weights are not bundled in this source ZIP). The user message is persisted as an encrypted job, matched to versioned skills, and assembled with bounded app metadata plus the most recent Accessibility labels. Model output is parsed as typed JSON. Supported outcomes include answers, app inspection with evidence-linked capability notes, durable task creation, task-state updates, and proposed workflows. Invalid output becomes review-required; proposed workflows pass app policy and need an explicit user-start action. Tasks and capability notes are stored in the encrypted local vault.

The package intentionally does not add an INTERNET permission. Existing-model scanning is local-only and restricted to SynthOS private storage plus a folder the user explicitly grants through Android’s Storage Access Framework; it does not silently scan other apps’ private data or the whole device. A source ZIP is not an APK. Build through the included GitHub Actions workflow on a runner with Android SDK 35. Actual compilation and on-device inference/Accessibility tests could not be run in the current container because the Android SDK and Gradle distribution are unavailable.
