# SynthOS App Runtime — Architecture & Design Contract

## Principal Architect role

Act as a principal Android automation-runtime architect with expertise in Kotlin/Java Android lifecycle, Accessibility and UI Automator, device/guest execution surfaces, local-first persistence, threat modeling, agent planning, deterministic workflow execution, behavioral instrumentation, mobile UX and release engineering. Optimize for evidence-backed execution rather than impressive demos. Never equate a model's proposed action with a verified result.

## Product lock

**Name:** SynthOS App Runtime  
**Purpose:** a local-first mobile control surface for authoring, launching and inspecting repeatable workflows across app surfaces.  
**User problem:** repetitive application workflows are scattered across interfaces and difficult to resume or audit.  
**Core loop:** choose target app → author explicit steps → inspect the plan → grant runtime access → run while visible/unlocked → verify visible state changes → inspect the run ledger → edit or repeat.

The first installed build now includes a real LiteRT-LM inference gateway and a local job/skill pipeline, but it does not bundle model weights. The user imports a compatible `.litertlm` model. A headless guest runtime remains an execution-host capability and is not simulated by the UI layer. No cloud inference is used.

## Design principles

1. Evidence before claims: a run completes only after the defined steps finish without an execution error; an explicit `WAIT_TEXT` step is required when the user wants an end-state assertion.
2. User agency: every workflow is authored and started by the user; cancellation is obvious.
3. Local by default: private state remains in the app sandbox and the network permission is absent.
4. Honest capability boundaries: locked-screen UI automation and custom-drawn surfaces are not represented as supported.
5. Motion clarifies state: animations are short, repeatable, and reduced when the OS prefers reduced motion in future refinements.

## Visual identity

SynthOS is a calm, technical, tactile control room. A concentric orbital mark represents the shared workflow engine and multiple execution surfaces. The visual language uses dark graphite, mint-green execution status, warm amber caution and generous spacing; light mode is also supported via system appearance.

## Color tokens

Tokens are implemented in `DesignSystem.Colors` and derived from system appearance.

| Token | Dark | Light | Use |
|---|---|---|---|
| `bg` | `#0B1015` | `#F5F8F9` | Main background |
| `surface` | `#11181F` | `#FFFFFF` | Cards, dialogs |
| `surface2` | `#172029` | `#EBF2F2` | Raised/interactive surface |
| `surface3` | `#1F2B35` | `#DEE9E9` | Secondary surface |
| `border` | `#2B3A44` | `#CDDCDD` | Separators and outlines |
| `text` | `#EDF4F6` | `#132429` | Primary text |
| `textMuted` | `#97ABB2` | `#4F676C` | Supporting text |
| `primary` | `#62E6C7` | `#00705B` | Primary actions / active state |
| `primaryDim` | `#184B42` | `#D3F2EA` | Tinted surfaces |
| `accent` | `#F5B96B` | `#8B4F0D` | Accent / attention |
| `success` | `#62E6A5` | `#00794B` | Verified success |
| `warning` | `#F5B96B` | `#8B4F0D` | Locked or caution |
| `error` | `#FF7781` | `#B12737` | Failure/destructive state |
| `info` | `#75BEFF` | `#1A5EA3` | Neutral information |

Contrast depends on pairing, so text must be checked against the chosen surface before adding new variants. Never use semantic color as the sole indicator; labels and icons accompany run-state colors.

## Type, layout, shapes and components

- Typeface: Android system Sans (`sans-serif`); bold for headings and control labels.
- Scale: display 31sp; hero 27sp; screen headline 28sp; card title 16–18sp; body 13–15sp; label 9–11sp; metadata 10–12sp.
- Base spacing: 4dp. Common scale: 4, 8, 10, 12, 16, 20, 24, 32dp.
- Main horizontal inset: 20dp. Main scroll inset: 16dp top / 26dp bottom.
- Touch target: buttons/navigation controls are 48dp or larger wherever practical.
- Radius tokens used: 12dp (compact tags), 15–16dp (buttons), 20–22dp (cards), 26dp (hero), pill radius for state chips.
- Borders: 1dp; no heavy shadows. Surface contrast and thin outlines establish depth.
- Components: primary/secondary buttons, cards, status chips, empty states, step rows, run timeline rows, text fields and native confirmation dialogs. Native controls retain built-in screen-reader semantics.
- Accessibility: visible labels, accessibility pane title for hero, content descriptions for workflow cards, system-managed focus order, no color-only status signals. Accessibility service use is explained before Settings opens.
- Theme follows Android system light/dark appearance.
- Copy is concise and states effects directly. Avoid success claims without runtime evidence.

## Motion system

Tokens live in `DesignSystem.Motion` and `DesignSystem.bindPress`.

| Token | Duration | Use |
|---|---:|---|
| `INSTANT` | 100ms | Press-down feedback |
| `FAST` | 180ms | Release / simple UI feedback |
| `STANDARD` | 280ms | Screen appearance |
| `DELIBERATE` | 420ms | State changes that need orientation |
| `EXPRESSIVE` | 700ms | Reserved for success/illustration emphasis |

- Press scales to 0.975 and springs back with an overshoot interpolator.
- Haptic feedback uses the system keyboard tick for direct actions; do not create custom vibration patterns.
- Home hero orbital outlines rotate slowly; the connected-state dot pulses; empty-state glyph has a very slow rotation.
- Screen appearance uses opacity plus a small vertical offset. Runtime status and run-state labels update reactively from durable data.
- Performance: transforms and opacity only for ambient motion; no per-frame bitmap allocation or blocking main-thread inference.
- `DesignSystem.animationsEnabled` reads Android’s animator duration scale. When the OS animation scale is zero, ambient loops and press transitions are skipped; no feature depends on animation to operate.

## Runtime architecture

- `MainActivity`: UI, authentication gate, workflow authoring, execution preview and export flow.
- `SynthStore`: process-singleton durable store, schema version 1, encrypted at rest using AES-256-GCM with an Android Keystore key. Atomic file replacement protects existing data.
- `Workflow` / `WorkflowStep`: small JSON-serializable workflow schema.
- `WorkflowPolicy`: validates step limits and blocks high-risk action strings related to artificial ad engagement, reward claims, CAPTCHA/security bypass and payment confirmation.
- `AutomationAccessibilityService`: executes explicit steps against visible accessible UI nodes, with retries, wait deadlines, lock pause and durable event logging.
- `DesignSystem`: single token authority for colors, shapes and motion.
- No cloud/backend or sync. No network permission.

## Workflow schema

```json
{
  "id": "uuid",
  "name": "My workflow",
  "targetPackage": "com.example.app",
  "targetLabel": "Example",
  "createdAt": 0,
  "updatedAt": 0,
  "steps": [
    {"type": "LAUNCH_APP", "value": "", "delayMillis": 0},
    {"type": "WAIT_TEXT", "value": "Ready", "delayMillis": 0},
    {"type": "TAP_TEXT", "value": "Continue", "delayMillis": 0},
    {"type": "BACK", "value": "", "delayMillis": 0},
    {"type": "DELAY", "value": "", "delayMillis": 1000}
  ]
}
```

The local planner can propose a workflow in this schema. The app validates it against policy and requires explicit user-start; model output alone cannot launch actions. Accessibility acknowledgements are not proof that the requested outcome happened, so a run may remain unverified without an observed postcondition.

## Security boundaries

- Internal data: AES-256-GCM; key in Android Keystore; files private to app UID.
- Local unlock: Android biometric/device credential; if the device is not secured, the workspace remains unavailable until a screen lock is configured.
- `FLAG_SECURE` prevents screenshots and recent-task snapshots.
- No internet permission, no analytics, no secrets or endpoint credentials.
- Accessibility service runs only after user opt-in in system settings. Do not list it as a generic capability hidden from the user.
- Plain JSON export is only user-initiated and warned as unencrypted.
- Backup is disabled at Android level to avoid restoring encrypted data without the matching Keystore key.
- The default release configuration is signed with the generated debug key solely for installable CI testing; production release signing must use a stable private key injected from CI secrets.

## Lifecycle and failure model

- Start actions only when an Accessibility service is connected and the device is unlocked.
- Target launch failure, missing text, timeout, invalid workflow or persistence failure stops the run with a recorded error where possible.
- Locking the phone pauses before the next step; unlocking may resume from the current checkpoint while the process survives. If the target app leaves the foreground, UI actions pause rather than risk clicking a different app.
- Process death marks an active run `INTERRUPTED`; it does not resume automatically. This prevents a stale workflow from doing unreviewed work after restart.
- Run history capped to 60 runs; each run event list capped to 80 events.
- No arbitrary loops; max 30 steps; tap retries are bounded; visible-text wait timeout is 15 seconds; delay max is 30 seconds.

## Verification plan

1. Build release with JDK 17 and Android SDK 35.
2. Install on an Android 10+ device, set device credential, verify app unlock.
3. Create workflow targeting a simple app that has a visible labelled button.
4. Enable Accessibility and verify launch → wait → tap → back → delay sequence, including logs.
5. Verify missing text ends in `FAILED` and records a reason.
6. Lock the phone before a step; confirm run pauses and resumes only after unlock.
7. Force-stop/restart app; confirm interrupted run is not auto-replayed.
8. Export JSON; verify warning and file contents; confirm internal vault remains encrypted.
9. Inspect manifest to confirm there is no `INTERNET` permission and no broad `QUERY_ALL_PACKAGES` permission.
10. Before production, test on the actual device manufacturer/OS and conduct policy review for any planned autonomous agent and accessibility distribution.


## Apps workspace and SynthOS Live (implemented increment)

The host-device iteration now exposes an **Apps** tab with searchable launcher apps, app icons/package IDs, ordinary launch, and a user-triggered **Watch + control** flow. When enabled by the user, `AutomationAccessibilityService` draws a floating overlay above the selected app. It observes the target's accessible labels, distinguishes clickable labels, invokes only a visible matching accessibility click, offers Back/Refresh/Console, and keeps the latest snapshot in process memory. Password and editable-field values are excluded from the snapshot collector.

This is a visible host surface, not in-app embedding: arbitrary third-party apps still run in their own Android task. Apps that do not expose useful accessibility nodes remain partially or wholly unsupported. Android Accessibility and Display over other apps are separate user-granted permissions. Pixel-level live capture, guest execution, and unattended locked-screen automation remain separate future gates and are not represented as implemented here. The local model gateway, skill registry, job compiler, typed proposal parser and workflow-draft approval path are implemented in `ai/` and `MainActivity.java`; model weights are user-imported and runtime behavior still requires a device build/test.


## Current as-built local AI job path (26 October 2026)

```text
Chat message
  -> encrypted ChatMessage + JobRecord
  -> SkillRegistry.select(goal, observation availability)
  -> JobCompiler (goal + recent chat + installed launcher packages + last accessible snapshot)
  -> LocalModelRuntime (LiteRT-LM on-device, imported .litertlm file)
  -> PlanProposalParser (strict JSON, allowed job kinds and step types)
  -> target-package check + WorkflowPolicy
  -> encrypted job result and optional workflow draft
  -> explicit user review in Flows -> existing Accessibility workflow executor
```

The first registry contains versioned instructions for intent normalization, app surface inspection, capability mapping, task creation, workflow planning/validation, bounded action proposals, state verification, recovery, evidence and policy gating. Tasks and evidence-linked app capability notes are persisted in the encrypted vault. Skills are prompt/context assembly modules, not permission grants. The model cannot call Android APIs directly. Every request is persisted as a job; malformed proposals become `REVIEW_REQUIRED` and are not executed. Draft workflows are saved with `NEEDS_APPROVAL` and require the user to start them from Flows.

The app uses `com.google.ai.edge.litertlm:litertlm-android:0.18.0`. A compatible `.litertlm` file is imported into app-private storage; model downloads are opened in an external browser so SynthOS itself still has no `INTERNET` permission. This package has not been compiled/device-tested in the current container because the Android SDK and Gradle distribution are unavailable; CI build and real-device inference/permissions tests remain mandatory before treating it as release-verified.
