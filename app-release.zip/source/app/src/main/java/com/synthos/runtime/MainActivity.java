package com.synthos.runtime;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.hardware.biometrics.BiometricPrompt;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.synthos.runtime.data.RunRecord;
import com.synthos.runtime.data.SynthStore;
import com.synthos.runtime.data.Workflow;
import com.synthos.runtime.data.WorkflowStep;
import com.synthos.runtime.engine.AutomationAccessibilityService;
import com.synthos.runtime.engine.WorkflowPolicy;
import com.synthos.runtime.ui.DesignSystem;

import org.json.JSONException;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** SynthOS App Runtime. Native UI, local encrypted data, no network access. */
public class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 4102;
    private static final int REQUEST_ACCESSIBILITY = 4103;
    private static volatile MainActivity visibleActivity;
    private static volatile String serviceMessage = "";

    private SynthStore store;
    private DesignSystem.Colors colors;
    private String screen = "Home";
    private boolean unlocked = false;
    private boolean lockPromptShowing = false;
    private LinearLayout root, page;
    private FrameLayout contentFrame;
    private TextView runtimeStatusText;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private static final class LaunchableApp {
        String label, packageName;
        LaunchableApp(String label, String packageName) { this.label = label; this.packageName = packageName; }
        @Override public String toString() { return label; }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        colors = DesignSystem.Colors.forContext(this);
        getWindow().setStatusBarColor(colors.bg);
        getWindow().setNavigationBarColor(colors.bg);
        try {
            store = SynthStore.shared(this);
            if (!AutomationAccessibilityService.isExecuting()) store.recoverInterruptedRuns();
        } catch (IOException e) {
            store = null;
            showFatalStoreError(e.getMessage());
            return;
        }
        visibleActivity = this;
        showLockedShell();
        authenticateOrExplain();
    }

    @Override protected void onResume() {
        super.onResume();
        visibleActivity = this;
        if (unlocked && store != null) {
            colors = DesignSystem.Colors.forContext(this);
            uiHandler.post(this::renderScreen);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (visibleActivity == this) visibleActivity = null;
    }

    @Override protected void onDestroy() {
        if (visibleActivity == this) visibleActivity = null;
        super.onDestroy();
    }

    public static void notifyRuntimeChanged() {
        MainActivity a = visibleActivity;
        if (a != null) a.runOnUiThread(() -> { if (a.unlocked && a.store != null) a.renderScreen(); });
    }

    public static void showServiceMessage(String message) {
        serviceMessage = message == null ? "The runtime reported an issue." : message;
        MainActivity a = visibleActivity;
        if (a != null) a.runOnUiThread(() -> Toast.makeText(a, serviceMessage, Toast.LENGTH_LONG).show());
    }

    private void authenticateOrExplain() {
        KeyguardManager keyguard = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (keyguard == null || !keyguard.isDeviceSecure()) {
            showDeviceLockRequired();
            return;
        }
        if (Build.VERSION.SDK_INT >= 28 && !lockPromptShowing) {
            lockPromptShowing = true;
            BiometricPrompt.PromptInfo prompt = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Unlock SynthOS")
                    .setSubtitle("Your workflows and run history are encrypted on this device.")
                    .setDeviceCredentialAllowed(true)
                    .build();
            BiometricPrompt biometric = new BiometricPrompt(this, getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    lockPromptShowing = false; unlocked = true; renderScreen();
                }
                @Override public void onAuthenticationFailed() {
                    Toast.makeText(MainActivity.this, "Not recognised. Try again.", Toast.LENGTH_SHORT).show();
                }
                @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                    lockPromptShowing = false;
                    if (errorCode == BiometricPrompt.ERROR_USER_CANCELED || errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON || errorCode == BiometricPrompt.ERROR_CANCELED) {
                        showLockedShell();
                    } else {
                        showLockedShell(); Toast.makeText(MainActivity.this, errString, Toast.LENGTH_LONG).show();
                    }
                }
            });
            biometric.authenticate(prompt);
        } else {
            unlocked = true;
            renderScreen();
        }
    }

    private void showDeviceLockRequired() {
        LinearLayout box = column(this, 20); box.setPadding(dp(24), dp(40), dp(24), dp(24)); box.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("S  /  SYNTHOS", 14, colors.primary, Typeface.BOLD); logo.setLetterSpacing(.12f); box.addView(logo);
        space(box, 20);
        TextView h = text("Protect your\nautomation vault.", 31, colors.text, Typeface.BOLD); box.addView(h);
        space(box, 12);
        box.addView(text("SynthOS encrypts workflows and run history with a device-bound AES-256 key. Set a device screen lock before opening the workspace.", 15, colors.textMuted, Typeface.NORMAL));
        space(box, 20);
        Button setup = button("Open device security", true, () -> {
            try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Open Android Settings and set a screen lock.", Toast.LENGTH_LONG).show(); }
        }); box.addView(setup);
        space(box, 10);
        TextView retry = text("I've enabled a screen lock · Retry", 13, colors.primary, Typeface.BOLD); retry.setGravity(Gravity.CENTER); box.addView(retry, fullWrap());
        DesignSystem.bindPress(retry, () -> { recreate(); });
        setContentView(box);
    }

    private void showLockedShell() {
        LinearLayout box = column(this, 20); box.setPadding(dp(24), dp(40), dp(24), dp(24)); box.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("S  /  SYNTHOS", 14, colors.primary, Typeface.BOLD); logo.setLetterSpacing(.12f); box.addView(logo);
        space(box, 20);
        box.addView(text("Your runtime is\nlocked.", 31, colors.text, Typeface.BOLD));
        space(box, 12);
        box.addView(text("The workspace stays on this device. Authenticate to view workflows and execution history.", 15, colors.textMuted, Typeface.NORMAL));
        space(box, 20);
        Button unlock = button("Unlock workspace", true, this::authenticateOrExplain); box.addView(unlock);
        setContentView(box);
    }

    private void showFatalStoreError(String message) {
        LinearLayout box = column(this, 16); box.setPadding(dp(24), dp(40), dp(24), dp(24)); box.setGravity(Gravity.CENTER_VERTICAL);
        box.addView(text("Workspace could not be decrypted", 24, colors.error, Typeface.BOLD));
        box.addView(text(message == null ? "The local vault could not be opened. Existing data was not intentionally erased." : message, 15, colors.textMuted, Typeface.NORMAL));
        box.addView(button("Close", false, this::finish)); setContentView(box);
    }

    private void renderScreen() {
        if (!unlocked || store == null) return;
        colors = DesignSystem.Colors.forContext(this);
        getWindow().setStatusBarColor(colors.bg); getWindow().setNavigationBarColor(colors.bg);
        root = column(this, 0); root.setBackgroundColor(colors.bg);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }
        root.addView(buildHeader(), new LinearLayout.LayoutParams(-1, dp(74)));
        contentFrame = new FrameLayout(this);
        root.addView(contentFrame, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(buildBottomNav(), new LinearLayout.LayoutParams(-1, dp(76)));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 35) root.requestApplyInsets();
        buildPage();
        if (DesignSystem.animationsEnabled(this)) {
            root.setAlpha(0f); root.setTranslationY(dp(8));
            root.animate().alpha(1f).translationY(0).setDuration(DesignSystem.Motion.STANDARD).setInterpolator(DesignSystem.Motion.EXIT).start();
        } else { root.setAlpha(1f); root.setTranslationY(0f); }
    }

    private View buildHeader() {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(20), dp(12), dp(20), dp(8)); row.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout mark = new FrameLayout(this); mark.setBackground(DesignSystem.shape(colors.surface2, 15, colors.border, 1, this));
        TextView m = text("S", 24, colors.primary, Typeface.BOLD); m.setGravity(Gravity.CENTER); mark.addView(m, new FrameLayout.LayoutParams(-1,-1));
        row.addView(mark, new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout titles = column(this, 1); titles.setPadding(dp(11),0,0,0);
        TextView name = text("SYNTHOS", 15, colors.text, Typeface.BOLD); name.setLetterSpacing(.15f); titles.addView(name);
        TextView sub = text("APP RUNTIME", 10, colors.textMuted, Typeface.BOLD); sub.setLetterSpacing(.16f); titles.addView(sub);
        row.addView(titles, new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout pill = new LinearLayout(this); pill.setGravity(Gravity.CENTER); pill.setPadding(dp(10),dp(7),dp(10),dp(7));
        pill.setBackground(DesignSystem.shape(AutomationAccessibilityService.isConnected()?colors.primaryDim:colors.surface2,22,AutomationAccessibilityService.isConnected()?colors.primaryDim:colors.border,1,this));
        View dot = new View(this); dot.setBackground(DesignSystem.shape(AutomationAccessibilityService.isConnected()?colors.primary:colors.warning,99,Color.TRANSPARENT,0,this));
        pill.addView(dot, new LinearLayout.LayoutParams(dp(6),dp(6)));
        TextView pillText = text(AutomationAccessibilityService.isConnected()?"CONNECTED":"LOCAL", 10, AutomationAccessibilityService.isConnected()?colors.primary:colors.textMuted, Typeface.BOLD);
        pillText.setPadding(dp(6),0,0,0); pill.addView(pillText);
        if (AutomationAccessibilityService.isConnected()) pulse(dot);
        row.addView(pill);
        return row;
    }

    private View buildBottomNav() {
        LinearLayout nav = new LinearLayout(this); nav.setPadding(dp(8),dp(8),dp(8),dp(10)); nav.setGravity(Gravity.CENTER); nav.setBackground(DesignSystem.shape(colors.surface,22,colors.border,1,this));
        String[] labels = {"Home","Flows","Runs","Settings"}; String[] icons = {"◈","⌘","≋","⚙"};
        for (int i=0;i<labels.length;i++) {
            final String dest = labels[i]; boolean selected=screen.equals(dest);
            LinearLayout item = column(this,2); item.setGravity(Gravity.CENTER); item.setPadding(dp(8),dp(7),dp(8),dp(4));
            item.setBackground(DesignSystem.shape(selected?colors.primaryDim:Color.TRANSPARENT,16,Color.TRANSPARENT,0,this));
            TextView icon=text(icons[i],20,selected?colors.primary:colors.textMuted,Typeface.BOLD); icon.setGravity(Gravity.CENTER); item.addView(icon);
            TextView label=text(labels[i],10,selected?colors.primary:colors.textMuted,selected?Typeface.BOLD:Typeface.NORMAL); label.setGravity(Gravity.CENTER); item.addView(label);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,-1,1f); lp.setMargins(dp(3),0,dp(3),0); nav.addView(item,lp);
            item.setContentDescription(labels[i]+" navigation"); DesignSystem.bindPress(item,()->{screen=dest;renderScreen();});
        }
        return nav;
    }

    private void buildPage() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        page = column(this,16); page.setPadding(dp(20),dp(16),dp(20),dp(26));
        contentFrame.removeAllViews(); scroll.addView(page); contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1,-1));
        switch(screen) {
            case "Home": buildHome(); break;
            case "Flows": buildWorkflows(); break;
            case "Runs": buildRuns(); break;
            case "Settings": buildSettings(); break;
            default: screen="Home"; buildHome();
        }
    }

    private void buildHome() {
        int count=store.getWorkflows().size(); List<RunRecord> runs=store.getRuns();
        View hero = buildHero(); page.addView(hero, new LinearLayout.LayoutParams(-1,dp(214)));
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("RECIPES",String.valueOf(count),"repeatable workflows",colors.primary),new LinearLayout.LayoutParams(0,dp(96),1));
        View gap = new View(this); stats.addView(gap,new LinearLayout.LayoutParams(dp(10),1));
        long finished=runs.stream().filter(r->RunRecord.SUCCEEDED.equals(r.status)).count();
        stats.addView(statCard("COMPLETED RUNS",String.valueOf(finished),"completed locally",colors.accent),new LinearLayout.LayoutParams(0,dp(96),1)); page.addView(stats);

        LinearLayout runtime = cardColumn();
        rowLabel(runtime,"EXECUTION SURFACE","FORE­GROUND UI",colors.warning);
        runtime.addView(text("Visible Android session",18,colors.text,Typeface.BOLD));
        runtime.addView(text("The runner executes explicit, user-created steps through Android Accessibility. It pauses before UI actions when the phone is locked.",13,colors.textMuted,Typeface.NORMAL));
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(-1,dp(46)); buttonLp.topMargin=dp(4);
        runtime.addView(button(AutomationAccessibilityService.isConnected()?"Runtime is connected":"Connect Android runtime",true,this::openAccessibilitySettings),buttonLp);
        page.addView(runtime);

        LinearLayout shortcuts = new LinearLayout(this); shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        shortcuts.addView(button("＋  New workflow",true,()->showWorkflowEditor(null)),new LinearLayout.LayoutParams(0,dp(50),1));
        View g=new View(this); shortcuts.addView(g,new LinearLayout.LayoutParams(dp(10),1));
        shortcuts.addView(button("View runs",false,()->{screen="Runs";renderScreen();}),new LinearLayout.LayoutParams(0,dp(50),1)); page.addView(shortcuts);

        sectionHeading("RECENT ACTIVITY","Evidence, not assumptions");
        if(runs.isEmpty()) page.addView(emptyState("Nothing has run yet","Create a workflow, review every step, and start it when you're ready.","Add first workflow",()->showWorkflowEditor(null)));
        else for(int i=0;i<Math.min(3,runs.size());i++) page.addView(runCard(runs.get(i),true));

        LinearLayout privacy=cardColumn();
        rowLabel(privacy,"LOCAL BY DEFAULT","AES-256 · OFFLINE",colors.primary);
        privacy.addView(text("No network permission. Workflow definitions and run history are encrypted with an Android Keystore key. Nothing is sent to a cloud model.",13,colors.textMuted,Typeface.NORMAL));
        page.addView(privacy);
    }

    private View buildHero() {
        FrameLayout frame=new FrameLayout(this); frame.setClipToPadding(false); frame.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{colors.surface2,colors.primaryDim,colors.surface}));
        GradientDrawable outline=DesignSystem.shape(Color.TRANSPARENT,26,colors.border,1,this); frame.setForeground(outline);
        View orbit1=new View(this); orbit1.setBackground(DesignSystem.shape(Color.TRANSPARENT,150,colors.primary,1,this));
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(dp(154),dp(154),Gravity.RIGHT|Gravity.CENTER_VERTICAL); op.rightMargin=dp(-26); frame.addView(orbit1,op);
        View orbit2=new View(this); orbit2.setBackground(DesignSystem.shape(Color.TRANSPARENT,120,colors.primary,1,this));
        FrameLayout.LayoutParams op2=new FrameLayout.LayoutParams(dp(112),dp(112),Gravity.RIGHT|Gravity.CENTER_VERTICAL); op2.rightMargin=dp(-5); frame.addView(orbit2,op2);
        View core=new View(this); core.setBackground(DesignSystem.shape(colors.primary,99,Color.TRANSPARENT,0,this));
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.RIGHT|Gravity.CENTER_VERTICAL); cp.rightMargin=dp(42); frame.addView(core,cp);
        if (DesignSystem.animationsEnabled(this)) {
            android.animation.ObjectAnimator a1=android.animation.ObjectAnimator.ofFloat(orbit1,View.ROTATION,0f,360f); a1.setDuration(DesignSystem.Motion.AMBIENT_ORBIT); a1.setRepeatCount(android.animation.ValueAnimator.INFINITE); a1.setInterpolator(new android.view.animation.LinearInterpolator()); a1.start();
            android.animation.ObjectAnimator a2=android.animation.ObjectAnimator.ofFloat(orbit2,View.ROTATION,360f,0f); a2.setDuration(DesignSystem.Motion.AMBIENT_COUNTER_ORBIT); a2.setRepeatCount(android.animation.ValueAnimator.INFINITE); a2.setInterpolator(new android.view.animation.LinearInterpolator()); a2.start();
        }
        LinearLayout copy=column(this,8); copy.setPadding(dp(20),dp(22),dp(70),dp(18));
        TextView tag=text("LOCAL AUTOMATION / 01",10,colors.primary,Typeface.BOLD); tag.setLetterSpacing(.13f); copy.addView(tag);
        copy.addView(text("Make every step\ntraceable.",27,colors.text,Typeface.BOLD));
        copy.addView(text("One workflow engine. Native app surfaces. A clear record of what happened.",13,colors.textMuted,Typeface.NORMAL));
        LinearLayout status=new LinearLayout(this); status.setGravity(Gravity.CENTER_VERTICAL); status.setPadding(dp(9),dp(6),dp(9),dp(6)); status.setBackground(DesignSystem.shape(colors.surface,14,colors.border,1,this));
        View d=new View(this); d.setBackground(DesignSystem.shape(AutomationAccessibilityService.isConnected()?colors.success:colors.warning,99,Color.TRANSPARENT,0,this)); status.addView(d,new LinearLayout.LayoutParams(dp(7),dp(7)));
        TextView st=text(AutomationAccessibilityService.isConnected()?"CONTROL SURFACE READY":"NEEDS ACCESSIBILITY",9,colors.text,Typeface.BOLD); st.setPadding(dp(7),0,0,0); status.addView(st); copy.addView(status,wrap());
        frame.addView(copy,new FrameLayout.LayoutParams(-1,-1)); frame.setAccessibilityPaneTitle("SynthOS local automation overview");
        return frame;
    }

    private View statCard(String label,String value,String desc,int accent) {
        LinearLayout card=column(this,3); card.setPadding(dp(15),dp(13),dp(12),dp(10)); card.setBackground(DesignSystem.shape(colors.surface,20,colors.border,1,this));
        TextView l=text(label,9,colors.textMuted,Typeface.BOLD); l.setLetterSpacing(.08f); card.addView(l);
        TextView v=text(value,26,accent,Typeface.BOLD); card.addView(v); TextView d=text(desc,10,colors.textMuted,Typeface.NORMAL); card.addView(d);
        return card;
    }

    private void buildWorkflows() {
        page.addView(text("Workflows",28,colors.text,Typeface.BOLD));
        page.addView(text("Build repeatable sequences with explicit steps. Every run is recorded and verified against visible UI state.",14,colors.textMuted,Typeface.NORMAL));
        page.addView(button("＋  Create workflow",true,()->showWorkflowEditor(null)));
        List<Workflow> items=store.getWorkflows();
        if(items.isEmpty()) page.addView(emptyState("Your first recipe starts here","Choose an installed app, then add launch, tap, wait, back or delay steps.","Create workflow",()->showWorkflowEditor(null)));
        for(Workflow w:items) page.addView(workflowCard(w));
        LinearLayout note=cardColumn(); rowLabel(note,"EXECUTION RULE","VISIBLE UI ONLY",colors.warning);
        note.addView(text("UI workflows require an unlocked, visible Android session. SynthOS does not simulate ad views, claim reward payouts, bypass CAPTCHA or confirm payments.",12,colors.textMuted,Typeface.NORMAL)); page.addView(note);
    }

    private View workflowCard(Workflow w) {
        LinearLayout card=cardColumn();
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout textCol=column(this,4); TextView title=text(w.name,17,colors.text,Typeface.BOLD); title.setMaxLines(2); textCol.addView(title);
        textCol.addView(text(w.targetLabel+"  ·  "+w.steps.size()+" step"+(w.steps.size()==1?"":"s"),12,colors.textMuted,Typeface.NORMAL));
        head.addView(textCol,new LinearLayout.LayoutParams(0,-2,1)); TextView edit=text("›",31,colors.textMuted,Typeface.NORMAL); edit.setPadding(dp(10),0,dp(5),0); head.addView(edit); card.addView(head);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.addView(button("Run workflow",true,()->confirmRun(w)),new LinearLayout.LayoutParams(0,dp(48),1));
        View gap=new View(this); actions.addView(gap,new LinearLayout.LayoutParams(dp(8),1));
        actions.addView(button("Edit",false,()->showWorkflowEditor(w)),new LinearLayout.LayoutParams(dp(94),dp(48))); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48)); lp.topMargin=dp(8); card.addView(actions,lp);
        card.setFocusable(true); card.setContentDescription(w.name+", target app "+w.targetLabel+", "+w.steps.size()+" steps");
        DesignSystem.bindPress(card,()->showWorkflowEditor(w));
        return card;
    }

    private void buildRuns() {
        page.addView(text("Run history",28,colors.text,Typeface.BOLD));
        page.addView(text("Every status is based on execution evidence, not an assumed success.",14,colors.textMuted,Typeface.NORMAL));
        if(AutomationAccessibilityService.isExecuting()) page.addView(button("Stop active run",false,()->new AlertDialog.Builder(this).setTitle("Stop this workflow?").setMessage("The workflow will stop at its next safe checkpoint. Partial external changes may already have occurred.").setNegativeButton("Keep running",null).setPositiveButton("Stop run",(d,w)->AutomationAccessibilityService.requestCancel()).show()));
        List<RunRecord> runs=store.getRuns();
        if(runs.isEmpty()) page.addView(emptyState("No run history","Start a workflow to see its timeline, pauses and verified results here.","Browse workflows",()->{screen="Flows";renderScreen();}));
        for(RunRecord r:runs) page.addView(runCard(r,false));
    }

    private View runCard(RunRecord r, boolean compact) {
        LinearLayout card=cardColumn();
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titleCol=column(this,4); titleCol.addView(text(r.workflowName,16,colors.text,Typeface.BOLD));
        titleCol.addView(text(formatTime(r.startedAt),11,colors.textMuted,Typeface.NORMAL)); header.addView(titleCol,new LinearLayout.LayoutParams(0,-2,1));
        TextView badge=text(statusLabel(r.status),10,statusColor(r.status),Typeface.BOLD); badge.setGravity(Gravity.CENTER); badge.setPadding(dp(8),dp(6),dp(8),dp(6)); badge.setBackground(DesignSystem.shape(colorWithAlpha(statusColor(r.status),34),14,statusColor(r.status),1,this)); header.addView(badge); card.addView(header);
        TextView msg=text(r.message == null ? "" : r.message,12,colors.textMuted,Typeface.NORMAL); msg.setMaxLines(compact?2:3); msg.setEllipsize(TextUtils.TruncateAt.END); card.addView(msg);
        if(!compact && !r.events.isEmpty()) {
            View divider=new View(this); divider.setBackgroundColor(colors.border); LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(1)); dl.topMargin=dp(5); dl.bottomMargin=dp(3); card.addView(divider,dl);
            int from=Math.max(0,r.events.size()-4);
            for(int i=from;i<r.events.size();i++) {
                String event=r.events.get(i); String[] parts=event.split("\\|",2); String val=parts.length>1?parts[1]:event;
                TextView line=text("·  "+val,11,colors.textMuted,Typeface.NORMAL); line.setPadding(dp(1),dp(3),0,dp(3)); card.addView(line);
            }
        }
        return card;
    }

    private void buildSettings() {
        page.addView(text("Runtime settings",28,colors.text,Typeface.BOLD));
        page.addView(text("Local control, explicit permissions and exportable workflow data.",14,colors.textMuted,Typeface.NORMAL));
        LinearLayout runtime=cardColumn(); rowLabel(runtime,"ACCESSIBILITY SURFACE",AutomationAccessibilityService.isConnected()?"CONNECTED":"DISCONNECTED",AutomationAccessibilityService.isConnected()?colors.success:colors.warning);
        runtime.addView(text("Android UI automation",17,colors.text,Typeface.BOLD));
        runtime.addView(text("SynthOS reads accessible UI labels and executes only the steps in the workflow you started. It cannot reliably operate UI while the phone is locked and will pause when it detects a lock.",13,colors.textMuted,Typeface.NORMAL));
        runtime.addView(button("Open accessibility settings",true,this::openAccessibilitySettings)); page.addView(runtime);

        LinearLayout privacy=cardColumn(); rowLabel(privacy,"SECURITY", "ON-DEVICE",colors.primary);
        privacy.addView(settingRow("Encrypted workspace","AES-256-GCM with a device-bound Android Keystore key"));
        privacy.addView(settingRow("Device authentication","Biometric or device credential at app entry"));
        privacy.addView(settingRow("Network access","No INTERNET permission; no cloud requests"));
        privacy.addView(settingRow("Screen privacy","Secure window flag disables screenshots and recents previews")); page.addView(privacy);

        LinearLayout exp=cardColumn(); rowLabel(exp,"PORTABILITY","USER-CONTROLLED",colors.accent);
        exp.addView(text("Export creates a readable JSON copy of workflow definitions and run history at the location you choose. The export is not encrypted; keep it private. Your encrypted on-device vault is never replaced by export.",12,colors.textMuted,Typeface.NORMAL));
        exp.addView(button("Export workspace JSON…",false,this::confirmExport)); page.addView(exp);

        LinearLayout boundaries=cardColumn(); rowLabel(boundaries,"EXECUTION BOUNDARIES","NO HIDDEN PROMISES",colors.warning);
        boundaries.addView(text("This MVP runs visible, user-authored workflows. Screen-off virtual-device execution and a local LLM are not included: the Android execution host must be proven first. SynthOS does not automate ad engagement, reward claims, CAPTCHA, security bypasses or payment confirmations.",12,colors.textMuted,Typeface.NORMAL)); page.addView(boundaries);
        page.addView(text("SYNTHOS RUNTIME  ·  0.1.0  ·  LOCAL-FIRST",10,colors.textMuted,Typeface.BOLD));
    }

    private View settingRow(String title,String subtitle) {
        LinearLayout row=column(this,3); row.setPadding(0,dp(5),0,dp(7)); row.addView(text(title,14,colors.text,Typeface.BOLD)); row.addView(text(subtitle,12,colors.textMuted,Typeface.NORMAL)); return row;
    }

    private void confirmRun(Workflow workflow) {
        String validation=WorkflowPolicy.validate(workflow);
        if(validation!=null){messageDialog("Workflow needs attention",validation);return;}
        LinearLayout detail=column(this,10); detail.setPadding(dp(22),dp(8),dp(22),dp(8));
        detail.addView(text("Target: "+workflow.targetLabel,14,colors.text,Typeface.BOLD));
        detail.addView(text(workflow.steps.size()+" explicit steps will run in order. SynthOS will stop when an expected UI state cannot be found.",13,colors.textMuted,Typeface.NORMAL));
        for(int i=0;i<workflow.steps.size();i++) {
            TextView s=text((i+1)+"   "+workflow.steps.get(i).label(),12,colors.text,Typeface.NORMAL); s.setPadding(dp(10),dp(8),dp(10),dp(8)); s.setBackground(DesignSystem.shape(colors.surface2,12,colors.border,1,this)); detail.addView(s);
        }
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Run "+workflow.name+"?").setView(detail).setNegativeButton("Not now",null).setPositiveButton("Start run",null).create();
        dialog.setOnShowListener(v->{ dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            if(!isAccessibilityEnabled()) { dialog.dismiss(); new AlertDialog.Builder(this).setTitle("Enable the runtime").setMessage("Android requires you to enable SynthOS in Accessibility settings before another app's visible UI can be controlled. Nothing runs until you enable it and start again.").setNegativeButton("Cancel",null).setPositiveButton("Open settings",(d,w)->openAccessibilitySettings()).show(); return; }
            if(!AutomationAccessibilityService.requestRun(this,workflow)) { Toast.makeText(this,"Accessibility is enabled but the service is not connected yet. Return here and retry.",Toast.LENGTH_LONG).show(); dialog.dismiss(); return; }
            dialog.dismiss(); screen="Runs"; renderScreen();
        }); }); dialog.show();
    }

    private void showWorkflowEditor(Workflow existing) {
        final boolean isNew=existing==null;
        final Workflow workflow;
        if(isNew) workflow=new Workflow("New workflow","", "Choose an app");
        else {
            try { workflow=Workflow.fromJson(existing.toJson()); } catch(JSONException e){ messageDialog("Could not edit workflow",e.getMessage()); return; }
        }
        List<LaunchableApp> apps=getLaunchableApps();
        LinearLayout form=column(this,10); form.setPadding(dp(22),dp(6),dp(22),dp(8));
        EditText name=input("Workflow name",workflow.name); form.addView(name);
        TextView appLabel=text("TARGET APP",10,colors.textMuted,Typeface.BOLD); appLabel.setLetterSpacing(.1f); form.addView(appLabel);
        Spinner appSpinner=new Spinner(this);
        ArrayList<LaunchableApp> choices=new ArrayList<>(); choices.add(new LaunchableApp("Choose installed app…",""));
        for(LaunchableApp app:apps) choices.add(app);
        ArrayAdapter<LaunchableApp> adapter=new ArrayAdapter<LaunchableApp>(this,android.R.layout.simple_spinner_item,choices) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) { TextView v=(TextView)super.getView(position,convertView,parent); v.setTextColor(colors.text); v.setTextSize(14); return v; }
            @Override public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convertView,parent);v.setTextColor(colors.text);v.setTextSize(15);v.setPadding(dp(12),dp(12),dp(12),dp(12));return v;}
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); appSpinner.setAdapter(adapter);
        for(int i=0;i<choices.size();i++) if(choices.get(i).packageName.equals(workflow.targetPackage)) {appSpinner.setSelection(i);break;}
        form.addView(appSpinner,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView stepsLabel=text("STEPS · IN EXECUTION ORDER",10,colors.textMuted,Typeface.BOLD); stepsLabel.setLetterSpacing(.1f); form.addView(stepsLabel);
        LinearLayout stepList=column(this,6); form.addView(stepList);
        Runnable renderSteps=()->{
            stepList.removeAllViews();
            if(workflow.steps.isEmpty()) stepList.addView(text("No steps yet. Add at least one explicit action.",12,colors.textMuted,Typeface.NORMAL));
            for(int index=0;index<workflow.steps.size();index++) {
                final int ix=index; WorkflowStep s=workflow.steps.get(index);
                LinearLayout item=new LinearLayout(this); item.setGravity(Gravity.CENTER_VERTICAL); item.setPadding(dp(11),dp(8),dp(8),dp(8)); item.setBackground(DesignSystem.shape(colors.surface2,13,colors.border,1,this));
                TextView n=text(String.format(Locale.US,"%02d",index+1),11,colors.primary,Typeface.BOLD); item.addView(n);
                TextView title=text(s.label(),12,colors.text,Typeface.NORMAL); title.setPadding(dp(9),0,dp(5),0); title.setMaxLines(3); item.addView(title,new LinearLayout.LayoutParams(0,-2,1));
                TextView del=text("×",21,colors.error,Typeface.BOLD); del.setGravity(Gravity.CENTER); item.addView(del,new LinearLayout.LayoutParams(dp(30),dp(34))); DesignSystem.bindPress(del,()->{workflow.steps.remove(ix);renderSteps.run();});
                stepList.addView(item);
            }
        };
        Button addStep=button("＋  Add a step",false,()->showStepTypeDialog(step->{workflow.steps.add(step);renderSteps.run();})); form.addView(addStep,new LinearLayout.LayoutParams(-1,dp(48)));
        renderSteps.run();
        TextView foot=text("Steps are fixed and user-authored. Exact visible text matching may fail on custom-drawn or inaccessible controls.",11,colors.textMuted,Typeface.NORMAL); form.addView(foot);
        ScrollView formScroll=new ScrollView(this); formScroll.setFillViewport(false); formScroll.addView(form);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(isNew?"New workflow":"Edit workflow").setView(formScroll).setNegativeButton("Cancel",null).setPositiveButton("Save workflow",null).create();
        if(!isNew) dialog.setButton(AlertDialog.BUTTON_NEUTRAL,"Delete",(d,w)->{
            new AlertDialog.Builder(this).setTitle("Delete workflow?").setMessage("“"+workflow.name+"” will be removed. Existing run history is kept.").setNegativeButton("Keep",null).setPositiveButton("Delete",(d2,w2)->{try{store.deleteWorkflow(workflow.id);renderScreen();}catch(IOException e){messageDialog("Delete failed",e.getMessage());}}).show();
        });
        dialog.setOnShowListener(v->{ dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view->{
            workflow.name=name.getText().toString().trim(); int selection=appSpinner.getSelectedItemPosition();
            if(selection>0){LaunchableApp app=choices.get(selection);workflow.targetPackage=app.packageName;workflow.targetLabel=app.label;}
            if(workflow.steps.stream().noneMatch(s->WorkflowStep.LAUNCH_APP.equals(s.type))) workflow.steps.add(0,new WorkflowStep(WorkflowStep.LAUNCH_APP,"",0));
            String validation=WorkflowPolicy.validate(workflow);
            if(validation!=null){messageDialog("Check this workflow",validation);return;}
            if(!packageExists(workflow.targetPackage)){messageDialog("Target app unavailable","This app is no longer launchable. Choose an installed app.");return;}
            try{store.saveWorkflow(workflow);dialog.dismiss();renderScreen();Toast.makeText(this,"Workflow saved",Toast.LENGTH_SHORT).show();}
            catch(IOException e){messageDialog("Could not save workflow",e.getMessage());}
        }); }); dialog.show();
    }

    private interface StepConsumer { void accept(WorkflowStep step); }
    private void showStepTypeDialog(StepConsumer consumer) {
        String[] options={"Tap visible text","Wait for visible text","Press Back","Wait 1 second"};
        new AlertDialog.Builder(this).setTitle("Add workflow step").setItems(options,(d,which)->{
            if(which==0 || which==1) {
                EditText value=input("Visible text to "+(which==0?"tap":"wait for"),"");
                new AlertDialog.Builder(this).setTitle(which==0?"Tap visible text":"Wait for visible text").setMessage("Use the exact label shown in the target app. Custom-drawn controls may not expose a label.").setView(padded(value)).setNegativeButton("Cancel",null).setPositiveButton("Add step",(d2,w)->{
                    String v=value.getText().toString().trim(); WorkflowStep step=new WorkflowStep(which==0?WorkflowStep.TAP_TEXT:WorkflowStep.WAIT_TEXT,v,0);
                    String blocked=WorkflowPolicy.validate(new Workflow("Check","com.example", "Example") {{steps.add(step);}});
                    if(blocked!=null){messageDialog("Step not allowed",blocked);return;} consumer.accept(step);
                }).show();
            } else if(which==2) consumer.accept(new WorkflowStep(WorkflowStep.BACK,"",0));
            else consumer.accept(new WorkflowStep(WorkflowStep.DELAY,"",1000));
        }).show();
    }

    private void openAccessibilitySettings() {
        new AlertDialog.Builder(this).setTitle("Connect Android runtime").setMessage("SynthOS uses an Accessibility Service to read visible UI labels and execute the exact steps in a workflow you start. This grants powerful cross-app control. Enable it only if you understand and trust this app. Workflows pause while the device is locked; ad engagement and sensitive security actions are blocked.").setNegativeButton("Cancel",null).setPositiveButton("Continue to settings",(d,w)->{
            try{startActivityForResult(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),REQUEST_ACCESSIBILITY);}catch(ActivityNotFoundException e){messageDialog("Settings unavailable","Open Android Settings → Accessibility and enable SynthOS App Runtime.");}
        }).show();
    }

    private boolean isAccessibilityEnabled() {
        String expected=new ComponentName(this,AutomationAccessibilityService.class).flattenToString();
        try {
            int enabled=Settings.Secure.getInt(getContentResolver(),Settings.Secure.ACCESSIBILITY_ENABLED,0); if(enabled!=1)return false;
            String services=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return services!=null && services.toLowerCase(Locale.ROOT).contains(expected.toLowerCase(Locale.ROOT));
        } catch(Exception e){return false;}
    }

    private List<LaunchableApp> getLaunchableApps() {
        ArrayList<LaunchableApp> apps=new ArrayList<>(); Intent query=new Intent(Intent.ACTION_MAIN,null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm=getPackageManager(); List<ResolveInfo> matches=pm.queryIntentActivities(query,0);
        for(ResolveInfo r:matches) {
            if(r.activityInfo==null || getPackageName().equals(r.activityInfo.packageName)) continue;
            String label=r.loadLabel(pm).toString(); apps.add(new LaunchableApp(label,r.activityInfo.packageName));
        }
        apps.sort((a,b)->a.label.compareToIgnoreCase(b.label)); return apps;
    }
    private boolean packageExists(String packageName){return packageName!=null&&!packageName.isEmpty()&&getPackageManager().getLaunchIntentForPackage(packageName)!=null;}

    private void confirmExport() {
        new AlertDialog.Builder(this).setTitle("Export workspace?").setMessage("The export is readable JSON and is not encrypted. It contains workflow definitions and run history. Save it only to a location you trust.").setNegativeButton("Cancel",null).setPositiveButton("Choose location",(d,w)->{
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json"); intent.putExtra(Intent.EXTRA_TITLE,"synthos-workspace-export.json");
            try{startActivityForResult(intent,REQUEST_EXPORT);}catch(Exception e){messageDialog("Export unavailable",e.getMessage());}
        }).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_ACCESSIBILITY){if(unlocked)renderScreen();return;}
        if(requestCode==REQUEST_EXPORT && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())) {
                if(out==null)throw new IOException("Android did not provide an output stream.");
                out.write(store.exportPlainJson().getBytes(StandardCharsets.UTF_8)); out.flush();
                Toast.makeText(this,"Workspace exported",Toast.LENGTH_LONG).show();
            } catch(Exception e){messageDialog("Export failed",e.getMessage());}
        }
    }

    private View emptyState(String title,String body,String action,Runnable runnable) {
        LinearLayout box=column(this,10); box.setGravity(Gravity.CENTER); box.setPadding(dp(22),dp(25),dp(22),dp(24)); box.setBackground(DesignSystem.shape(colors.surface,22,colors.border,1,this));
        FrameLayout illustration=new FrameLayout(this); illustration.setBackground(DesignSystem.shape(colors.surface2,32,colors.border,1,this));
        TextView icon=text("✳",34,colors.primary,Typeface.NORMAL); icon.setGravity(Gravity.CENTER); illustration.addView(icon,new FrameLayout.LayoutParams(-1,-1));
        box.addView(illustration,new LinearLayout.LayoutParams(dp(72),dp(72)));
        if (DesignSystem.animationsEnabled(this)) { android.animation.ObjectAnimator rotate=android.animation.ObjectAnimator.ofFloat(icon,View.ROTATION,0f,360f); rotate.setDuration(DesignSystem.Motion.AMBIENT_COUNTER_ORBIT); rotate.setRepeatCount(android.animation.ValueAnimator.INFINITE); rotate.setInterpolator(new android.view.animation.LinearInterpolator()); rotate.start(); }
        box.addView(text(title,18,colors.text,Typeface.BOLD)); TextView descr=text(body,13,colors.textMuted,Typeface.NORMAL); descr.setGravity(Gravity.CENTER); box.addView(descr);
        box.addView(button(action,true,runnable));
        return box;
    }

    private void sectionHeading(String title,String subtitle) {
        LinearLayout row=column(this,4); TextView t=text(title,10,colors.primary,Typeface.BOLD);t.setLetterSpacing(.12f);row.addView(t);row.addView(text(subtitle,13,colors.textMuted,Typeface.NORMAL)); page.addView(row);
    }
    private LinearLayout cardColumn() {
        LinearLayout v=column(this,10); v.setPadding(dp(16),dp(15),dp(16),dp(15)); v.setBackground(DesignSystem.shape(colors.surface,22,colors.border,1,this)); return v;
    }
    private void rowLabel(LinearLayout parent,String label,String value,int color) {
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); TextView l=text(label,9,colors.textMuted,Typeface.BOLD);l.setLetterSpacing(.10f);row.addView(l,new LinearLayout.LayoutParams(0,-2,1));
        TextView v=text(value,9,color,Typeface.BOLD); v.setPadding(dp(8),dp(5),dp(8),dp(5));v.setBackground(DesignSystem.shape(colorWithAlpha(color,28),12,colorWithAlpha(color,110),1,this));row.addView(v);parent.addView(row);
    }
    private LinearLayout column(Context context,int gapDp) { LinearLayout l=new LinearLayout(context); l.setOrientation(LinearLayout.VERTICAL); l.setClipToPadding(false); if(gapDp>0){GradientDrawable divider=new GradientDrawable();divider.setColor(Color.TRANSPARENT);divider.setSize(1,dp(gapDp));l.setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);l.setDividerDrawable(divider);} return l; }
    private TextView text(String value,float size,int color,int style) { TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setTypeface(DesignSystem.typeface(style));t.setIncludeFontPadding(false);t.setLineSpacing(dp(2),1f);t.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);return t; }
    private EditText input(String hint,String value) { EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setTextColor(colors.text);e.setHintTextColor(colors.textMuted);e.setHint(hint);e.setText(value);e.setPadding(dp(13),dp(10),dp(13),dp(10));e.setBackground(DesignSystem.shape(colors.surface2,13,colors.border,1,this));return e; }
    private View padded(View v){LinearLayout l=column(this,0);l.setPadding(dp(22),dp(6),dp(22),dp(6));l.addView(v);return l;}
    private Button button(String title,boolean primary,Runnable action) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(title);b.setTextSize(13);b.setTypeface(DesignSystem.typeface(Typeface.BOLD));b.setMinHeight(dp(48));b.setPadding(dp(14),dp(7),dp(14),dp(7));
        b.setTextColor(primary?(isDark()?Color.rgb(9,30,28):Color.WHITE):colors.text);
        b.setBackground(DesignSystem.shape(primary?colors.primary:colors.surface2,15,primary?colors.primary:colors.border,1,this));
        b.setStateListAnimator(null); DesignSystem.bindPress(b,action); return b;
    }
    private boolean isDark(){return (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK)!=android.content.res.Configuration.UI_MODE_NIGHT_NO;}
    private LinearLayout.LayoutParams fullWrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private LinearLayout.LayoutParams wrap(){return new LinearLayout.LayoutParams(-2,-2);}
    private void space(LinearLayout parent,int height){parent.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height)));}
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private int colorWithAlpha(int color,int alpha){return (Math.min(255,alpha)<<24)|(color&0x00ffffff);}
    private String formatTime(long time){return DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT,Locale.getDefault()).format(new Date(time));}
    private String statusLabel(String s){if(RunRecord.RUNNING.equals(s))return "RUNNING";if(RunRecord.PAUSED_LOCKED.equals(s)||RunRecord.PAUSED_EXTERNAL.equals(s))return "PAUSED";if(RunRecord.SUCCEEDED.equals(s))return "COMPLETED";if(RunRecord.FAILED.equals(s))return "FAILED";if(RunRecord.CANCELLED.equals(s))return "STOPPED";if(RunRecord.INTERRUPTED.equals(s))return "INTERRUPTED";return s;}
    private int statusColor(String s){if(RunRecord.SUCCEEDED.equals(s))return colors.success;if(RunRecord.RUNNING.equals(s))return colors.primary;if(RunRecord.PAUSED_LOCKED.equals(s)||RunRecord.PAUSED_EXTERNAL.equals(s))return colors.warning;if(RunRecord.FAILED.equals(s)||RunRecord.INTERRUPTED.equals(s))return colors.error;if(RunRecord.CANCELLED.equals(s))return colors.textMuted;return colors.info;}
    private void pulse(View view){
        if(!DesignSystem.animationsEnabled(this)) return;
        android.animation.ObjectAnimator sx=android.animation.ObjectAnimator.ofFloat(view,View.SCALE_X,1f,1.4f,1f);
        android.animation.ObjectAnimator sy=android.animation.ObjectAnimator.ofFloat(view,View.SCALE_Y,1f,1.4f,1f);
        android.animation.ObjectAnimator alpha=android.animation.ObjectAnimator.ofFloat(view,View.ALPHA,1f,.45f,1f);
        sx.setDuration(DesignSystem.Motion.AMBIENT_PULSE); sy.setDuration(DesignSystem.Motion.AMBIENT_PULSE); alpha.setDuration(DesignSystem.Motion.AMBIENT_PULSE);
        sx.setRepeatCount(android.animation.ValueAnimator.INFINITE); sy.setRepeatCount(android.animation.ValueAnimator.INFINITE); alpha.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        android.animation.AnimatorSet set=new android.animation.AnimatorSet(); set.playTogether(sx,sy,alpha); set.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator()); set.start();
    }
    private void messageDialog(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message==null?"An unexpected error occurred.":message).setPositiveButton("OK",null).show();}
}
