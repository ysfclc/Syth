package com.synthos.runtime.engine;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import com.synthos.runtime.MainActivity;
import com.synthos.runtime.data.RunRecord;
import com.synthos.runtime.data.SynthStore;
import com.synthos.runtime.data.Workflow;
import com.synthos.runtime.data.WorkflowStep;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/** Executes only explicit, user-authored workflow steps. UI actions pause while the device is locked. */
public class AutomationAccessibilityService extends AccessibilityService {
    private static volatile AutomationAccessibilityService active;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SynthStore store;
    private Workflow workflow;
    private RunRecord run;
    private int stepIndex = 0;
    private int attempts = 0;
    private long waitDeadline = 0L;
    private boolean waitingForText = false;
    private boolean closing = false;
    private boolean storageFailureHandled = false;

    public static boolean isConnected() { return active != null; }
    public static boolean isExecuting() { return active != null && active.run != null && (RunRecord.RUNNING.equals(active.run.status) || RunRecord.PAUSED_LOCKED.equals(active.run.status) || RunRecord.PAUSED_EXTERNAL.equals(active.run.status)); }

    public static boolean requestRun(Context context, Workflow workflow) {
        AutomationAccessibilityService service = active;
        if (service == null || workflow == null) return false;
        service.handler.post(() -> service.begin(workflow));
        return true;
    }

    public static void requestCancel() {
        AutomationAccessibilityService service = active;
        if (service != null) service.handler.post(() -> service.finish(RunRecord.CANCELLED, "Stopped by you."));
    }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        active = this;
        try { store = SynthStore.shared(this); } catch (IOException e) { store = null; }
        MainActivity.notifyRuntimeChanged();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (workflow == null || run == null || closing) return;
        if (isDeviceLocked()) {
            if (RunRecord.RUNNING.equals(run.status)) pause("Device locked. UI execution paused.");
            return;
        }
        boolean targetForeground = isTargetForeground();
        if (RunRecord.PAUSED_LOCKED.equals(run.status) || RunRecord.PAUSED_EXTERNAL.equals(run.status)) {
            if (!targetForeground) return;
            run.status = RunRecord.RUNNING;
            record("Target app is foreground and the device is unlocked; resumed at step " + (stepIndex + 1) + ".");
            waitingForText = false;
            advance();
        } else if (!targetForeground) {
            if (stepIndex < workflow.steps.size() && !WorkflowStep.LAUNCH_APP.equals(workflow.steps.get(stepIndex).type)
                    && RunRecord.RUNNING.equals(run.status)) pauseExternal("Target app left the foreground. Paused to avoid touching another app.");
        } else if (waitingForText) {
            if (containsVisibleText(currentStepValue())) completeCurrentStep("Required text appeared.");
        }
    }

    @Override public void onInterrupt() {
        if (run != null && RunRecord.RUNNING.equals(run.status)) pause("Android interrupted UI access; waiting to resume safely.");
    }

    @Override public boolean onUnbind(Intent intent) {
        if (active == this) active = null;
        MainActivity.notifyRuntimeChanged();
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        if (active == this) active = null;
        handler.removeCallbacksAndMessages(null);
        MainActivity.notifyRuntimeChanged();
        super.onDestroy();
    }

    private void begin(Workflow requested) {
        if (run != null && (RunRecord.RUNNING.equals(run.status) || RunRecord.PAUSED_LOCKED.equals(run.status) || RunRecord.PAUSED_EXTERNAL.equals(run.status))) {
            record("Another workflow is active; finish or stop it first.");
            MainActivity.notifyRuntimeChanged();
            return;
        }
        String validation = WorkflowPolicy.validate(requested);
        if (validation != null) { MainActivity.showServiceMessage(validation); return; }
        if (isDeviceLocked()) { MainActivity.showServiceMessage("Unlock the device before starting a UI workflow."); return; }
        workflow = requested;
        run = new RunRecord(workflow.id, workflow.name);
        run.status = RunRecord.RUNNING;
        stepIndex = 0; attempts = 0; waitingForText = false; waitDeadline = 0L; closing = false;
        record("Run started · " + workflow.targetLabel);
        advance();
    }

    private void advance() {
        if (workflow == null || run == null || closing) return;
        if (isDeviceLocked()) { pause("Device locked. Workflow paused before the next UI action."); return; }
        if (stepIndex >= workflow.steps.size()) { finish(RunRecord.SUCCEEDED, "All configured steps completed. Add a Wait for visible text step when you need an explicit end-state check."); return; }
        WorkflowStep step = workflow.steps.get(stepIndex);
        if (!WorkflowStep.LAUNCH_APP.equals(step.type) && !WorkflowStep.DELAY.equals(step.type) && !isTargetForeground()) {
            pauseExternal("Target app is not foreground. Paused to avoid acting in another app."); return;
        }
        run.status = RunRecord.RUNNING;
        attempts = 0;
        record("Step " + (stepIndex + 1) + "/" + workflow.steps.size() + " · " + step.label());
        execute(step);
    }

    private void execute(WorkflowStep step) {
        if (isDeviceLocked()) { pause("Device locked before action. Unlock to continue."); return; }
        switch (step.type) {
            case WorkflowStep.LAUNCH_APP:
                try {
                    Intent intent = getPackageManager().getLaunchIntentForPackage(workflow.targetPackage);
                    if (intent == null) { finish(RunRecord.FAILED, "Target app has no launchable activity."); return; }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    stepIndex++;
                    handler.postDelayed(this::advance, 1200L);
                } catch (Exception e) { finish(RunRecord.FAILED, "Could not launch target app: " + safeMessage(e)); }
                break;
            case WorkflowStep.TAP_TEXT:
                if (findAndClick(step.value)) {
                    stepIndex++;
                    handler.postDelayed(this::advance, 480L);
                } else if (++attempts < 18) {
                    handler.postDelayed(() -> execute(step), 450L);
                } else {
                    finish(RunRecord.FAILED, "Could not find a clickable match for “" + step.value + "”. The app may not expose this control to Accessibility.");
                }
                break;
            case WorkflowStep.WAIT_TEXT:
                waitingForText = true;
                waitDeadline = System.currentTimeMillis() + 15000L;
                pollWaitText(step.value);
                break;
            case WorkflowStep.BACK:
                performGlobalAction(GLOBAL_ACTION_BACK);
                stepIndex++;
                handler.postDelayed(this::advance, 420L);
                break;
            case WorkflowStep.DELAY:
                stepIndex++;
                handler.postDelayed(this::advance, Math.max(0, Math.min(step.delayMillis, 30000)));
                break;
            default: finish(RunRecord.FAILED, "Unsupported workflow action.");
        }
    }

    private void pollWaitText(String value) {
        if (workflow == null || run == null || closing || !waitingForText) return;
        if (isDeviceLocked()) { pause("Device locked while waiting for visible text."); return; }
        if (containsVisibleText(value)) { completeCurrentStep("Required text found."); return; }
        if (System.currentTimeMillis() >= waitDeadline) { waitingForText = false; finish(RunRecord.FAILED, "Timed out waiting for “" + value + "”."); return; }
        handler.postDelayed(() -> pollWaitText(value), 450L);
    }

    private void completeCurrentStep(String note) {
        if (workflow == null || run == null || closing) return;
        waitingForText = false;
        record(note);
        stepIndex++;
        handler.postDelayed(this::advance, 250L);
    }

    private String currentStepValue() {
        if (workflow == null || stepIndex >= workflow.steps.size()) return "";
        return workflow.steps.get(stepIndex).value;
    }

    private boolean findAndClick(String desired) {
        if (desired == null || desired.trim().isEmpty()) return false;
        for (AccessibilityNodeInfo root : roots()) {
            try {
                if (clickMatch(root, desired.trim().toLowerCase(Locale.ROOT))) return true;
            } finally { try { root.recycle(); } catch (Exception ignored) {} }
        }
        return false;
    }

    private boolean clickMatch(AccessibilityNodeInfo node, String desired) {
        if (node == null) return false;
        CharSequence text = node.getText();
        CharSequence description = node.getContentDescription();
        if (matches(text, desired) || matches(description, desired)) {
            AccessibilityNodeInfo cursor = AccessibilityNodeInfo.obtain(node);
            for (int depth=0; cursor != null && depth<8; depth++) {
                if (cursor.isClickable() && cursor.isEnabled()) {
                    boolean performed = cursor.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    cursor.recycle();
                    if (performed) return true;
                    break;
                }
                AccessibilityNodeInfo parent = cursor.getParent();
                cursor.recycle(); cursor = parent;
            }
            if (node.isEnabled() && node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        }
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean found = clickMatch(child, desired);
                child.recycle();
                if (found) return true;
            }
        }
        return false;
    }

    private boolean containsVisibleText(String desired) {
        if (desired == null || desired.trim().isEmpty()) return false;
        String target = desired.trim().toLowerCase(Locale.ROOT);
        for (AccessibilityNodeInfo root : roots()) {
            try { if (containsInTree(root, target)) return true; }
            finally { try { root.recycle(); } catch (Exception ignored) {} }
        }
        return false;
    }

    private boolean containsInTree(AccessibilityNodeInfo node, String target) {
        if (node == null) return false;
        if (contains(node.getText(), target) || contains(node.getContentDescription(), target)) return true;
        for (int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) { boolean found = containsInTree(child,target); child.recycle(); if(found) return true; }
        }
        return false;
    }

    private List<AccessibilityNodeInfo> roots() {
        java.util.ArrayList<AccessibilityNodeInfo> out = new java.util.ArrayList<>();
        try {
            List<AccessibilityWindowInfo> windows = getWindows();
            for (AccessibilityWindowInfo window : windows) {
                if (window != null) {
                    AccessibilityNodeInfo root = window.getRoot();
                    if (root != null) out.add(root);
                }
            }
        } catch (Exception ignored) {}
        if (out.isEmpty()) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) out.add(root);
        }
        return out;
    }

    private boolean matches(CharSequence value, String desired) {
        return value != null && value.toString().trim().toLowerCase(Locale.ROOT).equals(desired);
    }
    private boolean contains(CharSequence value, String desired) {
        return value != null && value.toString().toLowerCase(Locale.ROOT).contains(desired);
    }
    private boolean isDeviceLocked() {
        KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        return km != null && km.isKeyguardLocked();
    }

    private void pause(String message) {
        if (run == null || closing) return;
        run.status = RunRecord.PAUSED_LOCKED;
        record(message);
        MainActivity.notifyRuntimeChanged();
    }

    private void pauseExternal(String message) {
        if (run == null || closing) return;
        run.status = RunRecord.PAUSED_EXTERNAL;
        record(message);
        MainActivity.notifyRuntimeChanged();
    }

    private boolean isTargetForeground() {
        if (workflow == null || workflow.targetPackage == null || workflow.targetPackage.isEmpty()) return false;
        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null || root.getPackageName() == null) return false;
            return workflow.targetPackage.contentEquals(root.getPackageName());
        } catch (Exception ignored) { return false; }
        finally { if (root != null) try { root.recycle(); } catch (Exception ignored) {} }
    }

    private void finish(String status, String message) {
        if (run == null || closing) return;
        handler.removeCallbacksAndMessages(null);
        closing = true; waitingForText = false;
        run.status = status; run.finishedAt = System.currentTimeMillis(); record(message);
        persistRun(); MainActivity.notifyRuntimeChanged();
        workflow = null; run = null; stepIndex = 0;
        closing = false;
    }

    private void record(String message) {
        if (run == null) return;
        run.stepIndex = stepIndex;
        run.addEvent(message);
        persistRun();
        MainActivity.notifyRuntimeChanged();
    }

    private void persistRun() {
        try { if (store == null) store = SynthStore.shared(this); if (store != null && run != null) store.saveRun(run); }
        catch (IOException e) {
            MainActivity.showServiceMessage("Run history could not be saved securely. The workflow was stopped.");
            if (!storageFailureHandled) {
                storageFailureHandled = true;
                handler.post(() -> { waitingForText = false; workflow = null; run = null; stepIndex = 0; closing = false; MainActivity.notifyRuntimeChanged(); });
            }
        }
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage(); return m == null || m.trim().isEmpty() ? e.getClass().getSimpleName() : m;
    }
}
