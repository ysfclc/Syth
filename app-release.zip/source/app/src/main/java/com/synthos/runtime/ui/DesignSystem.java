package com.synthos.runtime.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** Single source of truth for visual tokens and interaction motion. */
public final class DesignSystem {
    private DesignSystem() {}

    public static final class Motion {
        public static final long INSTANT = 100L;
        public static final long FAST = 180L;
        public static final long STANDARD = 280L;
        public static final long DELIBERATE = 420L;
        public static final long EXPRESSIVE = 700L;
        public static final long AMBIENT_ORBIT = 9000L;
        public static final long AMBIENT_COUNTER_ORBIT = 14000L;
        public static final long AMBIENT_PULSE = 1500L;
        public static final float PRESS_SCALE = 0.975f;
        public static final float ENTER_DISTANCE_DP = 12f;
        public static final DecelerateInterpolator EXIT = new DecelerateInterpolator(1.5f);
        public static final OvershootInterpolator SPRING = new OvershootInterpolator(0.8f);
        private Motion() {}
    }

    public static final class Colors {
        public final int bg, surface, surface2, surface3, border, text, textMuted, primary, primaryDim,
                accent, success, warning, error, info;
        private Colors(boolean dark) {
            if (dark) {
                bg = Color.rgb(11,16,21); surface = Color.rgb(17,24,31); surface2 = Color.rgb(23,32,41);
                surface3 = Color.rgb(31,43,53); border = Color.rgb(43,58,68); text = Color.rgb(237,244,246);
                textMuted = Color.rgb(151,171,178); primary = Color.rgb(98,230,199); primaryDim = Color.rgb(24,75,66);
                accent = Color.rgb(245,185,107); success = Color.rgb(98,230,165); warning = Color.rgb(245,185,107);
                error = Color.rgb(255,119,129); info = Color.rgb(117,190,255);
            } else {
                bg = Color.rgb(245,248,249); surface = Color.WHITE; surface2 = Color.rgb(235,242,242);
                surface3 = Color.rgb(222,233,233); border = Color.rgb(205,220,221); text = Color.rgb(19,36,41);
                textMuted = Color.rgb(79,103,108); primary = Color.rgb(0,112,91); primaryDim = Color.rgb(211,242,234);
                accent = Color.rgb(139,79,13); success = Color.rgb(0,121,75); warning = Color.rgb(139,79,13);
                error = Color.rgb(177,39,55); info = Color.rgb(26,94,163);
            }
        }
        public static Colors forContext(Context context) {
            int mode = context.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            return new Colors(mode != Configuration.UI_MODE_NIGHT_NO);
        }
    }

    public static GradientDrawable shape(int color, float radiusDp, int strokeColor, float strokeDp, Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * density);
        if (strokeDp > 0) d.setStroke(Math.max(1, Math.round(strokeDp * density)), strokeColor);
        return d;
    }

    public static void bindPress(View view, Runnable action) {
        view.setClickable(true);
        view.setOnTouchListener((v, event) -> {
            if (!animationsEnabled(v.getContext())) return false;
            switch (event.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(Motion.PRESS_SCALE).scaleY(Motion.PRESS_SCALE).setDuration(Motion.INSTANT).setInterpolator(Motion.EXIT).start();
                    return false;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f).setDuration(Motion.FAST).setInterpolator(Motion.SPRING).start();
                    return false;
                default: return false;
            }
        });
        view.setOnClickListener(v -> {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            if (animationsEnabled(v.getContext())) {
                v.animate().scaleX(1.015f).scaleY(1.015f).setDuration(Motion.INSTANT)
                        .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f).setDuration(Motion.FAST).setInterpolator(Motion.SPRING).start()).start();
            }
            if (action != null) action.run();
        });
    }

    public static boolean animationsEnabled(Context context) {
        try { return android.provider.Settings.Global.getFloat(context.getContentResolver(), android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f; }
        catch (Exception ignored) { return true; }
    }

    public static Typeface typeface(int style) { return Typeface.create("sans-serif", style); }
}
