package com.synthos.runtime.data;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Encrypted, offline-first store. The AES-GCM key is generated and retained by Android Keystore. */
public final class SynthStore {
    private static final String KEY_ALIAS = "synthos.runtime.store.v1";
    private static final String FILE_NAME = "synthos-vault.bin";
    private static volatile SynthStore sharedInstance;
    private final Context appContext;
    private final File storeFile;
    private JSONObject cached;

    public static synchronized SynthStore shared(Context context) throws IOException {
        if (sharedInstance == null) sharedInstance = new SynthStore(context);
        return sharedInstance;
    }

    public SynthStore(Context context) throws IOException {
        appContext = context.getApplicationContext();
        storeFile = new File(appContext.getFilesDir(), FILE_NAME);
        synchronized (this) { cached = readFile(); }
    }

    private JSONObject emptyData() {
        JSONObject o = new JSONObject();
        try { o.put("schemaVersion", 1); o.put("workflows", new JSONArray()); o.put("runs", new JSONArray()); o.put("updatedAt", System.currentTimeMillis()); }
        catch (JSONException ignored) {}
        return o;
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        java.security.Key existing = ks.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setKeySize(256)
                .build());
        return generator.generateKey();
    }

    private JSONObject readFile() throws IOException {
        if (!storeFile.exists()) return emptyData();
        try (FileInputStream in = new FileInputStream(storeFile); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096]; int n; while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
            byte[] payload = out.toByteArray();
            if (payload.length < 14) throw new IOException("Encrypted workspace is incomplete.");
            int ivLength = payload[0] & 0xff;
            if (ivLength < 12 || ivLength > 16 || payload.length <= ivLength + 1) throw new IOException("Encrypted workspace has an invalid header.");
            byte[] iv = new byte[ivLength]; System.arraycopy(payload, 1, iv, 0, ivLength);
            byte[] cipherText = new byte[payload.length - 1 - ivLength]; System.arraycopy(payload, 1 + ivLength, cipherText, 0, cipherText.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            byte[] plain = cipher.doFinal(cipherText);
            JSONObject result = new JSONObject(new String(plain, StandardCharsets.UTF_8));
            if (result.optInt("schemaVersion", 0) != 1) throw new IOException("Unsupported workspace schema version.");
            return result;
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Could not decrypt workspace. It was not overwritten; export or restore a valid backup if available.", e); }
    }

    private void persist() throws IOException {
        try {
            cached.put("updatedAt", System.currentTimeMillis());
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] iv = cipher.getIV(); byte[] encrypted = cipher.doFinal(cached.toString().getBytes(StandardCharsets.UTF_8));
            File temp = new File(storeFile.getParentFile(), FILE_NAME + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write(iv.length); out.write(iv); out.write(encrypted); out.flush(); out.getFD().sync();
            }
            android.system.Os.rename(temp.getAbsolutePath(), storeFile.getAbsolutePath());
        } catch (IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Could not encrypt workspace with Android Keystore.", e); }
    }

    public synchronized List<Workflow> getWorkflows() {
        JSONArray a = cached.optJSONArray("workflows"); ArrayList<Workflow> out = new ArrayList<>();
        if (a != null) for (int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o!=null) out.add(Workflow.fromJson(o)); }
        Collections.sort(out, (x,y) -> Long.compare(y.updatedAt, x.updatedAt)); return out;
    }
    public synchronized Workflow getWorkflow(String id) {
        for (Workflow w : getWorkflows()) if (w.id.equals(id)) return w; return null;
    }
    public synchronized void saveWorkflow(Workflow workflow) throws IOException {
        workflow.updatedAt = System.currentTimeMillis(); JSONArray a = cached.optJSONArray("workflows"); if(a==null) a = new JSONArray();
        JSONArray next = new JSONArray(); boolean replaced = false;
        try {
            for(int i=0;i<a.length();i++) { JSONObject o=a.optJSONObject(i); if(o==null) continue; if(o.optString("id").equals(workflow.id)) { next.put(workflow.toJson()); replaced=true; } else next.put(o); }
            if(!replaced) next.put(workflow.toJson()); cached.put("workflows", next); persist();
        } catch(JSONException e) { throw new IOException("Could not serialize workflow.",e); }
    }
    public synchronized void deleteWorkflow(String id) throws IOException {
        JSONArray a=cached.optJSONArray("workflows"), next=new JSONArray();
        if(a!=null) for(int i=0;i<a.length();i++){ JSONObject o=a.optJSONObject(i); if(o!=null&&!o.optString("id").equals(id)) next.put(o); }
        try { cached.put("workflows",next); persist(); } catch(JSONException e){ throw new IOException(e); }
    }
    public synchronized void saveRun(RunRecord run) throws IOException {
        JSONArray a=cached.optJSONArray("runs"), next=new JSONArray(); boolean replaced=false;
        try {
            if(a!=null) for(int i=0;i<a.length();i++){ JSONObject o=a.optJSONObject(i); if(o==null) continue; if(o.optString("id").equals(run.id)){next.put(run.toJson());replaced=true;}else next.put(o);}
            if(!replaced) next.put(run.toJson());
            while(next.length()>60) { JSONArray trimmed=new JSONArray(); for(int i=next.length()-60;i<next.length();i++) trimmed.put(next.get(i)); next=trimmed; }
            cached.put("runs",next); cached.put("activeRunId", (RunRecord.RUNNING.equals(run.status)||RunRecord.PAUSED_LOCKED.equals(run.status)||RunRecord.PAUSED_EXTERNAL.equals(run.status)) ? run.id : ""); persist();
        } catch(JSONException e) { throw new IOException("Could not save run history.", e); }
    }
    public synchronized List<RunRecord> getRuns() {
        JSONArray a=cached.optJSONArray("runs"); ArrayList<RunRecord> out=new ArrayList<>();
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(RunRecord.fromJson(o));}
        out.sort((x,y)->Long.compare(y.startedAt,x.startedAt)); return out;
    }
    public synchronized void recoverInterruptedRuns() throws IOException {
        boolean changed=false;
        for(RunRecord run:getRuns()) if(RunRecord.RUNNING.equals(run.status)||RunRecord.PAUSED_LOCKED.equals(run.status)||RunRecord.PAUSED_EXTERNAL.equals(run.status)) {
            run.status=RunRecord.INTERRUPTED; run.finishedAt=System.currentTimeMillis(); run.addEvent("App process restarted; execution did not resume automatically."); saveRun(run); changed=true;
        }
        if(!changed && cached.optString("activeRunId", "").length()>0) { try { cached.put("activeRunId",""); persist(); } catch(JSONException e){ throw new IOException(e); } }
    }
    public synchronized String exportPlainJson() { return cached.toString(2); }
    public synchronized boolean hasWorkflows() { JSONArray a=cached.optJSONArray("workflows"); return a!=null && a.length()>0; }
}
