# SynthOS App Runtime

SynthOS is a local-first Android app workspace with a conversation-driven job runner. It brings together real installed apps, live Accessibility observations, reusable job skills, on-device model inference, reviewable workflows, and an encrypted evidence ledger.

## Included in this source package

- **Apps workspace:** enumerate launchable apps installed on the phone, search them, launch them, or choose **Watch + control**.
- **SynthOS Live:** floating panel over the real selected app, with accessible UI labels, manual control of exposed controls, Back, Refresh, collapse/drag, and return-to-console.
- **Conversation-first Home:** ask SynthOS to inspect an observed app, create a task, explain what the exposed UI suggests, or draft a repeatable workflow in natural language.
- **Local model gateway:** LiteRT-LM Android runtime, loaded from a user-imported `.litertlm` model file. Model weights are not bundled in this source ZIP or APK.
- **Model library:** multiple compatible `.litertlm` files can coexist in app-private storage; each import gets a content-hash-based filename so it does not overwrite another model. The user can choose the active model. Inference loads one model at a time on-device. There is no built-in model downloader.
- **Skill registry:** versioned reusable skills for intent normalization, surface inspection, capability mapping, task creation, workflow planning/validation, bounded actions, verification, recovery, evidence and policy.
- **Job compiler:** assembles the user's goal, selected skill instructions, bounded recent chat history, launchable-app list, and the latest observed accessible labels into a task-specific request.
- **Typed proposal parser:** accepts `answer`, `inspect_app`, `create_task`, `set_task_status`, `action_plan`, `draft_workflow`, or `needs_input`. Workflow proposals are limited to 12 model-proposed steps and five known step types. Unsupported output is saved as a review-required job and never executed.
- **Explicit approval boundary:** model-generated workflows are saved to Flows as drafts. They are never executed automatically by model inference; a user must review and start them.
- **Durable entities:** conversations, jobs, selected skill IDs/versions, tasks, app capability notes, model output, workflow links, run records and results are stored in the encrypted AES-256-GCM vault using Android Keystore.
- **Live app observation:** Accessibility snapshots include accessible labels and clickability, excluding password and editable-field values. The model receives only the selected snapshot, not arbitrary screenshots or unrestricted UI dumps.
- **Native workflow executor:** launch app, tap visible accessible text, wait for visible text, Back, and delay. Run records capture the outcomes and current blockers.

## Local model setup

1. Build and install SynthOS. Open **Settings → Local AI**.
2. Use **Import model (.litertlm)** to choose a compatible model file in Android Files. SynthOS copies it into app-private storage, calculates SHA-256, and retains existing imported model files.
3. Import another compatible `.litertlm` model whenever needed, then use **Choose active model** to switch between imported models. Only one model is loaded into the inference engine at a time. Check the model card/license and ensure your device has sufficient free storage and RAM.
4. Return to Home and send a request. The model initializes on the first request; model loading can take time. Inference runs with the local LiteRT-LM CPU backend and may be slow on lower-memory devices.
5. To inspect an app, use **Apps → Watch + control**, enable the required Android Accessibility and overlay permissions, interact with the real app, then return to SynthOS. Ask SynthOS to study the **last observed** app surface.
6. To draft an automation, describe the outcome in chat. Review the saved proposal in **Flows** and start it explicitly when ready.

**Format matters:** this build's runtime loads compatible `.litertlm` files only. It does not load GGUF, `.task`, `.tflite`, or unconverted model checkpoints directly. Multiple files are supported, but per-role model routing, concurrent engines, a model downloader, GGUF/llama.cpp and vision inference are not implemented yet. Qwen 2.5 `.task` files are not interchangeable with the starter Qwen2 `.litertlm` file.

## Build

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and network access to fetch the Gradle plugins/runtime dependency on the build machine.

```bash
cd source
./gradlew --no-daemon clean assembleRelease
```

APK output: `source/app/build/outputs/apk/release/app-release.apk`. The GitHub Actions workflow publishes the `app-apk` artifact. The release variant uses a generated debug signing key for sideload tests, not a production Play Store signature.

## Product boundaries

- A normal Android app cannot arbitrarily embed another installed app's Activity inside its own window. Apps open as real Android apps, with SynthOS's floating panel layered over the selected foreground app; this is not a pixel-stream mirror or a nested VM.
- Accessibility exposes only what each target app chooses to expose. Custom-drawn games and protected screens may show few or no semantic controls.
- Host UI execution requires the phone unlocked and the target surface interactive. Background scheduling is not represented as unattended app execution. Guest/remote Android execution is not implemented in this build.
- The model proposes; deterministic SynthOS code validates the output, checks target package membership and workflow policy, persists the job and requires the user to start any workflow. A model response or tap event is not treated as proof of external completion. Runs without a final visible-text condition are marked UNVERIFIED; VERIFIED requires the final workflow step to observe its expected visible text.
- Inference and stored data remain local. The starter model link opens in the external browser; SynthOS itself has no `INTERNET` permission and does not download models or send user prompts over a network.
- The runner rejects workflows targeting ad engagement, reward claims, CAPTCHA/security bypasses, and payment confirmations.
- This package contains source, not a prebuilt APK. The current environment lacks the Android SDK and could not complete a device build/test, so build acceptance must be verified by the existing GitHub Actions workflow and a real phone.

## Source layout

```text
source/
  app/src/main/java/com/synthos/runtime/
    MainActivity.java                 conversation-first interface and approval flow
    ai/                               LiteRT-LM gateway, job compiler, skills, parser
    data/                             encrypted vault, chat messages, jobs, tasks, capabilities, workflows, runs
    engine/                           Accessibility surface, overlay and workflow executor
    ui/                               design system
  app/src/main/res/
  app/build.gradle
  build.gradle
  settings.gradle
```
