# SynthOS App Runtime

SynthOS is a local-first Android app workspace with a conversation-driven job runner. It brings together real installed apps, live Accessibility observations, reusable job skills, on-device model inference, reviewable workflows, and an encrypted evidence ledger.

## Included in this source package

- **Apps workspace:** enumerate launchable apps installed on the phone, search them, launch them, or choose **Watch + control**.
- **SynthOS Live:** floating panel over the real selected app, with accessible UI labels, manual control of exposed controls, Back, Refresh, collapse/drag, and return-to-console.
- **Conversation-first Home:** ask SynthOS to inspect an observed app, create a task, explain what the exposed UI suggests, or draft a repeatable workflow in natural language.
- **Local model gateway:** LiteRT-LM Android runtime, loaded from an app-private `.litertlm` file. Model weights are not bundled in this source ZIP or APK.
- **Model library and setup:** multiple compatible `.litertlm` files coexist in app-private storage. The one-click setup checks the private model library, can scan a user-authorized folder, and can download supported catalog entries. Catalog downloads are checked against published SHA-256 values before installation. User-imported files receive a local SHA-256 fingerprint; this does not by itself establish that they are valid models.
- **Model role routing:** optional assignments for general conversation, planning and screen interpretation; selected jobs route to these roles using bounded request heuristics and fall back to the active model when a role is not assigned. Models load one at a time to limit memory use.
- **Runtime self-test:** Settings can run a short local prompt against the active model. A downloaded/imported file is not labelled inference-ready until the user tests it.
- **Skill registry:** versioned reusable skills for intent normalization, surface inspection, capability mapping, task creation, workflow planning/validation, bounded actions, verification, recovery, evidence and policy.
- **Job compiler:** assembles the user's goal, selected skill instructions, bounded recent chat history, launchable-app list, and the latest observed accessible labels into a task-specific request.
- **Typed proposal parser:** accepts `answer`, `inspect_app`, `create_task`, `set_task_status`, `action_plan`, `draft_workflow`, or `needs_input`. Workflow proposals are limited to 12 model-proposed steps and five known step types. Unsupported output is saved as a review-required job and never executed.
- **Explicit approval boundary:** model-generated workflows are saved to Flows as drafts. They are never executed automatically by model inference; a user must review and start them.
- **Durable entities:** conversations, jobs, selected skill IDs/versions, tasks, app capability notes, model output, workflow links, run records and results are stored in the encrypted AES-256-GCM vault using Android Keystore.
- **Live app observation:** Accessibility snapshots include accessible labels and clickability, excluding password and editable-field values. The model receives only the selected snapshot, not arbitrary screenshots or unrestricted UI dumps.
- **Native workflow executor:** launch app, tap visible accessible text, wait for visible text, Back, and delay. Run records capture the outcomes and current blockers.

## Local model setup

1. Build and install SynthOS. Open **Settings → Local AI**.
2. Use **Import model (.litertlm)** to choose a compatible model file in Android Files. SynthOS copies it into app-private storage, calculates SHA-256, and retains existing imported model files.
3. Alternatively, use **One-click setup · scan for existing models**. SynthOS checks its private library, offers a user-granted folder scan, and provides a small catalog of LiteRT-LM downloads. Downloads are installed only after the published SHA-256 checksum matches. Downloads require internet; inference itself stays local.
4. Import additional compatible `.litertlm` models, use **Choose active model**, and optionally configure model roles. Only one model is loaded into the inference engine at a time. Check the model card/license and ensure your device has sufficient free storage and RAM.
5. Use **Test active model on this device** to verify that the selected model can initialize and return a response. This is a basic runtime test, not proof of suitability for every job or support for images.
6. Return to Home and send a request. The model initializes on first use; loading can take time. Inference uses the LiteRT-LM CPU backend and may be slow or fail on lower-memory devices.
5. To inspect an app, use **Apps → Watch + control**, enable the required Android Accessibility and overlay permissions, interact with the real app, then return to SynthOS. Ask SynthOS to study the **last observed** app surface.
6. To draft an automation, describe the outcome in chat. Review the saved proposal in **Flows** and start it explicitly when ready.

**Format matters:** this build's runtime loads compatible `.litertlm` files only. It detects but does not execute GGUF, `.task`, `.tflite`, ONNX, or unconverted checkpoints. GGUF/llama.cpp, concurrent model engines, automatic vision inference, model Council orchestration, and role-specific recovery execution are not yet implemented. A role assignment does not create capabilities the selected runtime/model does not support.

## Build

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and network access to fetch the Gradle plugins/runtime dependency on the build machine.

```bash
cd source
./gradlew --no-daemon clean assembleRelease
```

APK output: `source/app/build/outputs/apk/release/app-release.apk`. The GitHub Actions workflow publishes the `app-apk` artifact. The release variant uses a generated debug signing key for sideload tests, not a production Play Store signature.

## Product boundaries

- A normal Android app cannot arbitrarily embed another installed app's Activity inside its own window. Apps open as real Android apps, with SynthOS's floating panel layered over the selected foreground app; this is not a pixel-stream mirror or a nested VM.
- Accessibility exposes only what each target app chooses to expose. Custom-drawn games and protected screens may show few or no semantic controls.
- Host UI execution requires the phone unlocked and the target surface interactive. Background scheduling is not represented as unattended app execution. A separately configured remote/guest execution runtime is a product requirement but is not implemented in this build.
- The model proposes; deterministic SynthOS code validates the output, checks target package membership and workflow policy, persists the job and requires the user to start any workflow. A model response or tap event is not treated as proof of external completion. Runs without a final visible-text condition are marked UNVERIFIED; VERIFIED requires the final workflow step to observe its expected visible text.
- AI inference and stored data remain local. SynthOS has internet permission only for downloads the user explicitly starts in the model catalog; this release does not configure an external AI provider or send prompts to a cloud inference API.
- The runner rejects workflows targeting ad engagement, reward claims, CAPTCHA/security bypasses, and payment confirmations.
- This package contains source, not a prebuilt APK. The current environment could not download the Gradle distribution (DNS/network unavailable), so a full Android build and device test remain unverified. Run the existing GitHub Actions workflow and then test on a real phone before treating this as a release.

## Source layout

```text
source/
  app/src/main/java/com/synthos/runtime/
    MainActivity.java                 conversation-first interface and approval flow
    ai/                               LiteRT-LM gateway, job compiler, skills, parser
    data/                             encrypted vault, chat messages, jobs, tasks, capabilities, workflows, runs
    engine/                           Accessibility surface, overlay and workflow executor
    ui/                               design system
  app/src/main/res/
  app/build.gradle
  build.gradle
  settings.gradle
```
