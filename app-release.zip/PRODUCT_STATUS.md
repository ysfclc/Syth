# SynthOS whole-product audit — 26 October 2026

This is a source-level audit of the current archive, not a claim that the app has passed a build or device test. It records the confirmed product decisions and distinguishes implementation from remaining work.

## Product decisions locked

- AI inference is local-only. No external AI provider or cloud inference fallback is permitted.
- Internet access is allowed only for user-initiated model downloads and other explicitly approved non-AI transport required by a feature.
- Host Android UI execution and a separately configured remote/guest execution environment are distinct execution surfaces. Remote execution must not introduce a cloud AI provider.
- Preserve the current GitHub Actions workflow and exact archive name `app-release.zip`. Include an APK only when a build actually succeeds.
- Deliver the connected product, not an isolated model-setup feature.

## Source features found

| Area | Source-level state | Evidence / boundary |
|---|---|---|
| Android shell | Implemented | Native activity, Home/Apps/Flows/Runs/Settings screens and design system exist. Visual and device QA still required. |
| Authentication | Implemented | Entry authentication uses Android biometric/device credential APIs. Recovery and lock-state QA still required. |
| Encrypted persistence | Implemented | `SynthStore` uses AES-GCM with an Android Keystore key and atomic temporary-file replacement. Backup/restore and migration tests are incomplete. |
| Conversation/job pipeline | Partial | Local prompt compilation, skill selection, typed parsing, job persistence and entity creation for tasks exist. It is not a complete general-purpose entity graph or conversation workspace. |
| Skills | Implemented foundation | Versioned skill registry exists. More skills and evaluation tests are required. |
| Model runtime | Partial | LiteRT-LM CPU runtime supports one loaded model at a time. GGUF/llama.cpp and alternate runtime adapters are absent. |
| Model library/setup | Partial | Multiple `.litertlm` files can coexist; user-granted folder scanning, catalog downloads, published SHA-256 validation for two catalog entries, role assignment and a manual inference self-test are present in source. Device-wide private-folder scanning is not possible. Full downloader retry/resume and automated runtime validation after install remain incomplete. |
| Model routing | Partial | General/planner/screen/recovery roles can be assigned; current chat routing uses basic keyword/evidence heuristics and falls back to the active model. No Council orchestration or concurrent engines. |
| AI privacy | Implemented boundary | Inference runs through local LiteRT-LM; no cloud AI adapter is configured. Model downloads use network only after a user action. |
| Installed app discovery | Implemented foundation | Launchable apps can be listed and launched. Android package visibility and target app UI exposure limit discovery. |
| SynthOS Live | Implemented foundation | Accessibility-based live overlay and accessible controls exist. It is not a nested VM, pixel mirror, or universal embedded-app runtime. |
| Workflow proposals | Implemented foundation | Typed workflow proposals are validated and require user approval before starting. Supported steps are limited. |
| Workflow verification | Partial | Runs without a final visible-text condition end `UNVERIFIED`. A final `WAIT_TEXT` step can establish a limited visible-text condition, not arbitrary external success. |
| Browser workspace / DOM automation | Not implemented as a complete surface | Current code primarily exposes Android apps through Accessibility. Browser-specific DOM selectors, tabs/session management and site-specific reusable DOM adapters need implementation. |
| Multi-model Council | Not implemented | No independent/critic/debate/specialist orchestration, per-model evidence ledger, disagreement handling or synthesis stage. |
| Remote/guest execution | Not implemented | No paired remote runner protocol, authentication, health check, job handoff, remote evidence return, cancellation or reconciliation. |
| General entity graph | Partial | Tasks, app capabilities, jobs and workflows exist, but there is no unified arbitrary entity/relationship model across all product contexts. |
| Voice / multimodal capture | Not implemented as a complete feature | No complete voice conversation pipeline, image input pipeline, or verified multimodal model capability path. |
| Release automation | Workflow exists | `.github/workflows/build-apk.yml` extracts the archive and builds/signs an APK. This environment could not download Gradle, so compile status is unknown. Release signing is for sideload testing, not Play Store production. |

## Changes made in this delivery pass

- Added optional role assignments for general, planner and screen interpretation models.
- Routed chat jobs to the assigned planner/screen model when basic request heuristics select those roles, falling back to the active model.
- Added a manual local inference self-test in Settings.
- Added publisher SHA-256 checks to the two catalog downloads and quarantine of a pre-existing same-name file when its checksum is wrong.
- Corrected privacy copy to distinguish local inference from user-initiated model downloads.
- Removed an unsafe cleanup attempt on a LiteRT-LM engine whose `initialize()` call failed, in line with the runtime documentation.
- Updated README and this audit to document actual limits and unverified release status.

## Release gates still open

1. A successful Gradle `assembleDebug` and `assembleRelease` build in GitHub Actions.
2. Unit/integration tests for role routing, registry persistence, model download cancellation, checksum failure, interrupted imports, and workflow state transitions.
3. On-device tests for both catalog models on supported hardware, including low-memory and model-load failures.
4. Full UX and accessibility QA on real screen sizes and Android versions.
5. Implementation of the missing browser surface, Council orchestration, remote/guest runner, complete entity graph, and multimodal capture before calling the whole SynthOS product complete.

## Build verification status

**Not verified in this environment.** `./gradlew assembleDebug` could not start because `services.gradle.org` was not resolvable. ZIP integrity and static source checks are not substitutes for an Android build or device test.
