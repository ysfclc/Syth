# SynthOS Remote / Guest Runner v1

This is an optional Python 3.10+ companion service. It operates a separately paired Android guest/test device through ADB and UIAutomator. It is not a virtual machine and does not provide AI inference. The current Android UI does not yet include a complete pairing/configuration/status client; API tests can be run independently.

## Security boundary

- HTTPS with a trusted TLS certificate is mandatory; the service refuses to start without a certificate, private key and 32+ character bearer token.
- Bind to loopback behind a correctly configured HTTPS reverse proxy by default. Public binding requires an explicit environment acknowledgment. Protect the host firewall, proxy and ADB daemon.
- Run as a dedicated unprivileged account and pair only a dedicated test/guest device. Do not expose unauthenticated ADB over TCP.
- The service performs no AI inference and receives no chat, prompts, attachments, model weights or local model context.
- Only `LAUNCH_APP`, `TAP_TEXT`, `WAIT_TEXT`, `BACK` and bounded `DELAY` steps are accepted. Maximum 12 steps; final step must be `WAIT_TEXT`.
- Sensitive or consequential operations are conservatively blocked. Ambiguous or non-clickable text matches stop without tapping.
- Job state is stored in SQLite. In-flight jobs become `INTERRUPTED` on process restart and are not replayed automatically. Editable field values are not returned as observation evidence; raw hierarchy files are removed after inspection.

## Configure and run

Requirements: Python 3.10+, Android Platform Tools (`adb`), a separately paired guest device, TLS certificate/key and random secret.

```bash
cd remote-runner
export SYNTHOS_BEARER_TOKEN="$(python3 -c 'import secrets; print(secrets.token_urlsafe(40))')"
export SYNTHOS_TLS_CERT=/etc/ssl/certs/runner-fullchain.pem
export SYNTHOS_TLS_KEY=/etc/ssl/private/runner-key.pem
export SYNTHOS_RUNNER_DB=/var/lib/synthos/remote-jobs.sqlite3
export SYNTHOS_ADB=/usr/bin/adb
python3 server.py --host 127.0.0.1 --port 8765
```

Pair the guest interactively using `adb pair` / `adb connect`, authorize it on-device, and verify `adb get-state` reports `device` under the service account. Configure TLS termination, firewalling and service supervision before using any non-loopback endpoint.

## API

All endpoints require `Authorization: Bearer <token>`.

- `GET /health` — protocol version, capabilities, guest connectivity and `aiPolicy: local-only`.
- `POST /jobs` — JSON body `{ "workflow": { "name", "targetPackage", "steps" }, "approved": true }`. Explicit approval is required.
- `GET /jobs/<id>` — persisted job state and bounded evidence.
- `POST /jobs/<id>/cancel` — request cancellation at the next step boundary.

A workflow is `VERIFIED` only if the final visible-text postcondition was observed. A missing postcondition is `UNVERIFIED`. This companion has not been validated against a real guest device in this delivery pass.

## Tests

```bash
python3 -m unittest discover -s tests -v
```
